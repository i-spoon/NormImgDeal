﻿
// MFCView.cpp: CMFCView 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "MFC.h"
#endif

#include "MFCDoc.h"
#include "MFCView.h"
#include"CDialogMove.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMFCView

IMPLEMENT_DYNCREATE(CMFCView, CView)

BEGIN_MESSAGE_MAP(CMFCView, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CMFCView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_COMMAND(ID_FILE_OPEN, &CMFCView::OnFileOpen)
	ON_COMMAND(ID_GRAY, &CMFCView::OnGray)
	ON_COMMAND(ID_MOVE, &CMFCView::OnMove)
	ON_COMMAND(ID_Mirrors_Height, &CMFCView::OnMirrorsHeight)
	ON_COMMAND(ID_Mirrors_Width, &CMFCView::OnMirrorsWidth)
	ON_COMMAND(ID_IMAGE_T, &CMFCView::OnImageT)
	ON_WM_MOUSEWHEEL()
	ON_COMMAND(ID_TranA, &CMFCView::OnTrana)
	ON_COMMAND(ID_FILE_SAVE, &CMFCView::OnFileSave)
	ON_COMMAND(ID_Color_Back, &CMFCView::OnColorBack)
	ON_COMMAND(ID_Histogram, &CMFCView::OnHistogram)
	ON_COMMAND(ID_Log_Tran, &CMFCView::OnLogTran)
	ON_COMMAND(ID_Factor, &CMFCView::OnFactor)
	ON_COMMAND(ID_Equal, &CMFCView::OnEqual)
	ON_COMMAND(ID_BOX, &CMFCView::OnBox)
	ON_COMMAND(ID_Gauss, &CMFCView::OnGauss)
	ON_COMMAND(ID_Laplace, &CMFCView::OnLaplace)
	ON_COMMAND(ID_High_Filter, &CMFCView::OnHighFilter)
	ON_COMMAND(ID_Idea_Lower, &CMFCView::OnIdeaLower)
	ON_COMMAND(ID_Gauss_Lower, &CMFCView::OnGaussLower)
	ON_COMMAND(ID_Idea_Higher, &CMFCView::OnIdeaHigher)
	ON_COMMAND(ID_Gauss_Higher, &CMFCView::OnGaussHigher)
	ON_COMMAND(ID_BLower, &CMFCView::OnBlower)
	ON_COMMAND(ID_BHigher, &CMFCView::OnBhigher)
	ON_COMMAND(ID_GradX, &CMFCView::OnGradx)
	ON_COMMAND(ID_GradY, &CMFCView::OnGrady)
	ON_COMMAND(ID_GradSum, &CMFCView::OnGradsum)
	ON_COMMAND(ID_Log_Edge, &CMFCView::OnLogEdge)
	ON_COMMAND(ID_Canny_Edge, &CMFCView::OnCannyEdge)
	ON_COMMAND(ID_Otsu, &CMFCView::OnOtsu)
	ON_COMMAND(ID_FValue, &CMFCView::OnFvalue)
END_MESSAGE_MAP()

// CMFCView 构造/析构

CMFCView::CMFCView() noexcept
{
	// TODO: 在此处添加构造代码

}

CMFCView::~CMFCView()
{
}

BOOL CMFCView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CView::PreCreateWindow(cs);
}

// CMFCView 绘图

void CMFCView::OnDraw(CDC* pDC)
{
	CMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	if (!MyImage.IsNull()) {
		/*MyImage.Draw(pDC->GetSafeHdc(), 0, 0);*/
		CRect rectClient;
		GetClientRect(rectClient);
		CBrush br(0x111111);
		pDC->FillRect(rectClient, &br);
		double dWidth = MyImage.GetWidth();
		double dHeight = MyImage.GetHeight();
		double dWidthStr;
		double dHeightStr;
		if (dWidth > dHeight) {
			dWidthStr = rectClient.Width();
			dHeightStr = dWidthStr / dWidth*dHeight;
		}
		else {
			dHeightStr = rectClient.Height();
			dWidthStr = dHeightStr / dHeight * dWidth;
		}
		mRectDraw=CRect(CPoint((rectClient.Width() - dWidthStr) / 2, ((rectClient.Height() - dHeightStr) / 2)), CSize(dWidthStr, dHeightStr));
		int xDest = mRectDraw.TopLeft().x;
		int yDest = mRectDraw.TopLeft().y;
		int mDestWidth = mRectDraw.Width();
		int mDestHeight = mRectDraw.Height();

		int xSrc = mOriginSrcPoint.x;
		int ySrc = mOriginSrcPoint.y;
		int nSrcWidth = mWidthSrc;
		int nSrcHeight = mHeightSrc;
		DWORD dwRop = SRCCOPY;

		// 这个是相应的绘制操作

		CImage tmpImage;
		tmpImage.Create(MyImage.GetWidth(), MyImage.GetHeight(), MyImage.GetBPP(), 0);
		byte* pDataImage = (byte*)MyImage.GetBits();
		byte* pDataTmp = (byte*)tmpImage.GetBits();// 获取相应的色彩图
		int pitchImage = MyImage.GetPitch();
		int pitchTmp = tmpImage.GetPitch();
		int bitCountImage = MyImage.GetBPP() / 8;
		int bitCountTmp = tmpImage.GetBPP() / 8;
		RGBQUAD ColorTab[256];
		for (int i = 0; i < 256; i++)
				ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
		if (MyImage.GetBPP()==8) {
			tmpImage.SetColorTable(0, 256, ColorTab);
		}
	/*	tmpImage.SetColorTable(0, 256, ColorTab);*/
		for (int i = 0; i < MyImage.GetWidth(); i++)
			for (int j = 0; j < MyImage.GetHeight(); j++)
				for (int k = 0; k < MyImage.GetBPP() / 8; k++) {
					*(pDataTmp + pitchTmp * (MyImage.GetHeight() - j - 1) + i * bitCountImage+k) = *(pDataImage + pitchImage * j + i * bitCountImage+k);
				}
		// 专门负责绘图的
		tmpImage.StretchBlt(pDC->m_hDC,xDest, yDest, mDestWidth, dHeightStr,xSrc, ySrc, nSrcWidth, nSrcHeight, dwRop);
		// 
		// 只有最后绘制的时候使用自带的
	}
	CString cstr_OriginPoint;
	cstr_OriginPoint.Format(_T("Origin Point：(%d,%d)"), mOriginSrcPoint.x, mOriginSrcPoint.y);
	pDC->TextOut(0, 20, cstr_OriginPoint);
	//输出屏幕坐标：
	CString CStrPointScreen;
	CStrPointScreen.Format(_T("Screen Point：(%d,%d)"), mPtRollPointScreen.x, mPtRollPointScreen.y);
	pDC->TextOut(0, 40, CStrPointScreen);
	//输出滚轮坐标位置
	CString cstr_PointClient;
	cstr_PointClient.Format(_T("Client Point：(%d,%d)"), mPtRollPointClient.x, mPtRollPointClient.y);
	pDC->TextOut(0, 60, cstr_PointClient);
}


// CMFCView 打印


void CMFCView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CMFCView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CMFCView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CMFCView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}

void CMFCView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CMFCView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CMFCView 诊断

#ifdef _DEBUG
void CMFCView::AssertValid() const
{
	CView::AssertValid();
}

void CMFCView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMFCDoc* CMFCView::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMFCDoc)));
	return (CMFCDoc*)m_pDocument;
}
#endif //_DEBUG


// CMFCView 消息处理程序
bool CMFCView::AttachFromFile(CFile& file) {
	LPBYTE* lpData;
	BITMAPINFOHEADER* pBMIH;
	LPVOID lpvColorTable = NULL;
	int nColorTableEntries;
	BITMAPFILEHEADER bmfHead;
	if (!file.Read(&bmfHead, sizeof(bmfHead)))
		return FALSE;
	if (bmfHead.bfType != MAKEWORD('B', 'M'))
		return FALSE;
	pBMIH = (BITMAPINFOHEADER*)new BYTE[bmfHead.bfOffBits - sizeof(bmfHead)];
	if (!file.Read(pBMIH, bmfHead.bfOffBits - sizeof(bmfHead))) {
		delete pBMIH;
		return FALSE;
	}
	nColorTableEntries = (bmfHead.bfOffBits - sizeof(bmfHead) - sizeof(BITMAPINFOHEADER)) / sizeof(ClRgbQuad);
	if (nColorTableEntries > 0) {
		lpvColorTable = pBMIH + 1;
	}
	pBMIH->biHeight = abs(pBMIH->biHeight);
	int nWidthBytes = ((pBMIH->biWidth) * pBMIH->biBitCount);
	lpData = new LPBYTE[(pBMIH->biHeight)];
	for (int i = 0; i < (pBMIH->biHeight); i++) {
		lpData[i] = new BYTE[nWidthBytes];
		file.Read(lpData[i], nWidthBytes);
	}
	CleanUp();
	mLpData = lpData;
	mPBMIH = pBMIH;
	mLpvColorTable = lpvColorTable;
	mNColorTableEntries = nColorTableEntries;
}

// CleanUp 删除
void CMFCView::CleanUp() {
	if(mLpData!=nullptr)delete mLpData;
	if(mPBMIH!=nullptr) delete mPBMIH;
	mLpvColorTable = NULL;
	mNColorTableEntries = 0;
}

// 打开文件
void CMFCView::OnFileOpen()
{
	// TODO: 在此添加命令处理程序代码
	CFileDialog dlg(TRUE, _T("BMP"), _T("*.BMP"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("位图文件(*.BMP;*.jpg;*.png)|*.BMP;*.jpg;*.png|"));
	if (IDOK == dlg.DoModal())
	{
		/*LPCTSTR path = (dlg.GetPathName());*/
		if (!MyImage.IsNull()) MyImage.Destroy();
		FileName.Open(dlg.GetPathName(), CFile::modeReadWrite);
		extname = dlg.GetFileExt();//返回选定文件的扩展文件名
		FileName.Close();
		MyImage.dhLoadImage((dlg.GetPathName()));
		mFMultiple = 0;
		mWidthSrc = MyImage.GetWidth();
		mHeightSrc = MyImage.GetHeight();
		mOriginSrcPoint = (0, 0);   //将后缀名变成小写的
		Invalidate();
	}
	else if (IDCANCEL == dlg.DoModal()) {
		MessageBox(_T("未选择加载图片"));
		return;
	}
}

// 转换为相应的灰度图
void CMFCView::OnGray()
{
	// 导出为灰度图
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	
	if (!GrayImage.IsNull())
		GrayImage.Destroy();
	GrayImage.Create(width, height, 8, 0);
	ClRgbQuad ColorTab[256];
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	GrayImage.SetColorTable(0, 256, ColorTab);

	byte* pDataImage = (byte*)MyImage.GetBits();
	byte* pDataGray = (byte*)GrayImage.GetBits();// 获取相应的色彩图

	int pitchImage = MyImage.GetPitch();
	int pitchGray = GrayImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	int bitCountGray = GrayImage.GetBPP() / 8;
	if ((bitCountImage != 3) || (bitCountGray != 1))
		return;
	int tmpR, tmpG, tmpB, avg;

	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j <height; j++)
		{
			tmpR = *(pDataImage + pitchImage * j + i * bitCountImage);
			tmpG = *(pDataImage + pitchImage * j + i * bitCountImage + 1);
			tmpB = *(pDataImage + pitchImage * j + i * bitCountImage + 2);
			avg = (int)(tmpR * 0.299 + tmpG * 0.587 + tmpB * 0.114) + 0.5;
			//avg = (int)(tmpR + tmpG + tmpB) / 3;
			*(pDataGray + pitchGray * j + i * bitCountGray) = avg;
		}
	}
	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(width, height, 8, 0);
	pitchImage = MyImage.GetPitch();
	bitCountImage = MyImage.GetBPP() / 8;
	pDataImage = (byte*)MyImage.GetBits();
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	MyImage.SetColorTable(0, 256, ColorTab);
	for (int i = 0; i < width; i++)
		for (int j = 0; j <height; j++)
			*(pDataImage + pitchImage * j + i * bitCountImage) = *(pDataGray + pitchGray * j + i * bitCountImage);

	// 这个是相应的绘制操作
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}


// 移动相应的图像
bool CMFCView::MoveTranForm(int x, int y) {
	// 如果对应的值
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	MoveImage.Create(width + x, height + y, 8, 0);
	COLORREF pixel;
	byte* pDataImage = (byte*)MyImage.GetBits();
	byte* pDataMove = (byte*)MoveImage.GetBits();
	int pitchImage = MyImage.GetPitch();
	int pitchMove = MoveImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	int bitCountMove = MoveImage.GetBPP() / 8;
	for (int i = max(0, x); i < width + x; i++)
		for (int j = max(0, y); j < height + y; j++)
			*(pDataMove + pitchMove * j + i * bitCountMove) = (UCHAR)(*(pDataImage + pitchImage * (j - y) + (i - x) * bitCountImage));

	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(width, height, 8, 0);
	pDataImage = (byte*)MyImage.GetBits();
	pitchImage = MyImage.GetPitch();
	bitCountImage = MyImage.GetBPP() / 8;
	ClRgbQuad ColorTab[256];
	// 这是在绑定相应的色板
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	MyImage.SetColorTable(0, 256, ColorTab);

	for (int i = 0; i < width; i++)
		for (int j = 0; j < height; j++) {
			if ((x >= 0 && i < x) || (x<0 && i>=width + x)) {
				*(pDataImage + pitchImage * j + i * bitCountImage) = 255;
			}
			if ((y>=0&&j < y)||(y<0&&j>=height+y)) {
				*(pDataImage + pitchImage * j + i * bitCountImage) = 255;
			}
			else if ((x>=0&&y>=0&&i >= x && j >= y)||(x<0&&i<width+x&&y>=0&&j>=y)||(x<0&&i<width+x&&y<0&&j<height+y))
			*(pDataImage + pitchImage * j + i * bitCountImage) = (UCHAR)(*(pDataMove + pitchMove * j + i * bitCountMove));
		}
	Invalidate();

	return true;
}

// 平移函数
void CMFCView::OnMove()
{
	CDialogMove dlg;
	dlg.DoModal();
	int x = dlg.ValueX;
	int y = dlg.ValueY;
	// 对应的平移坐标
	MoveTranForm(y, x);
	// TODO: 在此添加命令处理程序代码
}

// 竖直反转
void CMFCView::OnMirrorsHeight()
{
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	int pitchImage = MyImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	byte* pDataImage = (byte*)MyImage.GetBits();
	int tmpR, tmpG, tmpB, avg;
	for (int i = 0; i < width-i-1; i++){
		for (int j = 0; j < height; j++){
			int tmp = *(pDataImage + pitchImage * j + i * bitCountImage);
			*(pDataImage + pitchImage * j + i * bitCountImage) = *(pDataImage + pitchImage * j + (width-i-1) * bitCountImage);
			*(pDataImage + pitchImage *j + (width-i-1) * bitCountImage) = tmp;
		}
	}
	Invalidate();// 最后的绘制操作
	return;
	// TODO: 在此添加命令处理程序代码
}

// 水平反转
void CMFCView::OnMirrorsWidth()
{
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	int pitchImage = MyImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	byte* pDataImage = (byte*)MyImage.GetBits();
	int tmpR, tmpG, tmpB, avg;
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height-j-1; j++) {
			int tmp = *(pDataImage + pitchImage * j + i * bitCountImage);
			*(pDataImage + pitchImage * j + i * bitCountImage) = *(pDataImage + pitchImage * (height-j-1) + i * bitCountImage);
			*(pDataImage + pitchImage * (height - j - 1) + i * bitCountImage) = tmp;
		}
	}
	Invalidate();// 最后的绘制操作
	return;
	// TODO: 在此添加命令处理程序代码
}

// 图像转置
void CMFCView::OnImageT()
{
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	MoveImage.Create(width, height, 8, 0);
	int pitchImage = MyImage.GetPitch();
	int pitchMove = MoveImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() /8;
	int bitCountMove = MoveImage.GetBPP()/8;
	byte* pDataImage = (byte*)MyImage.GetBits();
	byte* pDataMove = (byte*)MoveImage.GetBits();
	int tmpR, tmpG, tmpB, avg;
	for (int i = 0; i < width; i++) 
		for (int j = 0; j <height; j++) 
			*(pDataMove + pitchMove * j + i * bitCountMove) = *(pDataImage + pitchImage * (height - j - 1) + (width-i-1) * bitCountImage);
	
	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(width, height, 8, 0);
	ClRgbQuad ColorTab[256];
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	MyImage.SetColorTable(0, 256, ColorTab);
	pitchImage = MyImage.GetPitch();
	bitCountImage = MyImage.GetBPP() / 8;
	pDataImage = (byte*)MyImage.GetBits();
	for (int i = 0; i < width; i++)
		for (int j = 0; j < height; j++)
			*(pDataImage + pitchImage * j + i * bitCountImage) = *(pDataMove + pitchMove * j + i*bitCountMove);
	Invalidate();// 最后的绘制操作
	return;
	// TODO: 在此添加命令处理程序代码
}

// 按照鼠标滚轮的旋转和缩放
BOOL CMFCView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	mPtRollPointScreen = pt;// 目录中心登录相应的中心
	mPtRollPointClient = pt;
	// 传入相应的坐标指针
	ScreenToClient(&mPtRollPointClient);
	if (!MyImage.IsNull()) {
		CPoint ptTemp = mOriginSrcPoint;
		int nTempWidth = mWidthSrc;
		int nTempHeight = mHeightSrc;
		if (zDelta > 0) {
			// 判断相应的滚轮位置
			if (mPtRollPointClient.x < mRectDraw.TopLeft().x||mPtRollPointClient.x>mRectDraw.BottomRight().x) {
				return CView::OnMouseWheel(nFlags, zDelta, pt);
			}
			else if (mWidthSrc < 50 || mHeightSrc < 50) {
				return CView::OnMouseWheel(nFlags, zDelta, pt);
			}
			mFMultiple = 0.1;
			mWidthSrc = mWidthSrc * (1 - mFMultiple);
			mHeightSrc = mHeightSrc * (1 - mFMultiple);
			float nDeltax = mPtRollPointClient.x - float(mRectDraw.TopLeft().x);
			float fPosXRation = nDeltax / float(mRectDraw.Width());
			float nDeltay = mPtRollPointClient.y - float(mRectDraw.TopLeft().y);
			float fPosYRation = nDeltay / float(mRectDraw.Height());
			mOriginSrcPoint.x += (nTempWidth - mWidthSrc) * fPosXRation;
			mOriginSrcPoint.y += (nTempHeight - mHeightSrc) * fPosYRation;

		}
		else {
			if (mPtRollPointClient.x<mRectDraw.TopLeft().x || mPtRollPointClient.x>mRectDraw.BottomRight().x) {
				return CView::OnMouseWheel(nFlags, zDelta, pt);
			}
			mFMultiple = -0.1;
			mWidthSrc = mWidthSrc * (1 - mFMultiple);
			mHeightSrc = mHeightSrc * (1 - mFMultiple);
			mOriginSrcPoint.x += (nTempWidth - mWidthSrc) * 0.5;
			mOriginSrcPoint.y += (nTempHeight - mHeightSrc) * 0.5;

		}
		Invalidate();
	}
	return CView::OnMouseWheel(nFlags, zDelta, pt);
}

// 旋转相应的角度
bool CMFCView::TranA(float a) {
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	MoveImage.Create(width, height, 8, 0);
	COLORREF pixel;
	byte* pDataImage = (byte*)MyImage.GetBits();
	byte* pDataMove = (byte*)MoveImage.GetBits();
	int pitchImage = MyImage.GetPitch();
	int pitchMove = MoveImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	int bitCountMove = MoveImage.GetBPP() / 8;
	// 注意的是围绕他的中心旋转	
	// 将矩阵设置为相应的右乘操作
	memset(A, 0, sizeof(A));
	memset(B, 0, sizeof(B));
	A[0][0] = A[1][1] = A[2][2] = 1;
	A[0][2] = width / 2.0;
	A[1][2] = height / 2.0;

	B[2][2] = 1;
	B[0][0]=B[1][1] = cos(a);
	B[1][0] = -sin(a);
	B[0][1] = sin(a);

	MatrixMulitpy();

	memset(B, 0, sizeof(B));
	B[0][0] = B[1][1] = B[2][2] = 1;
	B[0][2] = -width / 2.0;
	B[1][2] = -height / 2.0;

	MatrixMulitpy();
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			*((pDataMove + pitchMove * j + i * bitCountMove)) = 255;
		}
	}
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			int xx = i *A[0][0] + j * A[0][1]+A[0][2];
			int yy = i *A[1][0] + j * A[1][1]+A[1][2];

			if (xx < 0 || yy < 0 || xx >= height || yy >=width) continue;
			*(pDataMove + pitchMove * yy + xx * bitCountMove) = *((pDataImage + pitchImage * j + i * bitCountImage));

			// 会产生比较大的失真 本质上是因为处理的时候造成的
		}
	}
	
	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(width, height, 8, 0);
	pDataImage = (byte*)MyImage.GetBits();
	pitchImage = MyImage.GetPitch();
	bitCountImage = MyImage.GetBPP() / 8;
	ClRgbQuad ColorTab[256];
	// 这是在绑定相应的色板
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	MyImage.SetColorTable(0, 256, ColorTab);
	// 将未被旋转的区域置为白色

	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			*(pDataImage + pitchImage * j + i * bitCountMove) = *((pDataMove + pitchMove * j + i * bitCountMove));
		}
	}
	Invalidate();
	return TRUE;
}

// 相应的转置矩阵的乘法 采用的是右乘的方式
void CMFCView::MatrixMulitpy() {
	double tmp[3][3];
	memset(tmp, 0, sizeof(tmp));

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			for (int k = 0; k < 3; k++) {
				tmp[i][j] += A[i][k] * B[k][j];
			}
		}
	}

	// 完成相应的赋值操作
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++)
			A[i][j] = tmp[i][j];
	}
}

// 旋转相应的a度角度
void CMFCView::OnTrana()
{
	// 设置相应的旋转函数
	CTranA dlg;
	dlg.DoModal();
	// 传递过来相应的数值
	float valueA = dlg.mValueA;
	valueA = valueA / 180 * PI;
	TranA(valueA);
	// 转换成相应的弧度制
	// 	   对于相应的c++而言，其sin和cos均为弧度制的方式
	// TODO: 在此添加命令处理程序代码
}


void CMFCView::OnFileSave()
{
	CFileDialog dlg(TRUE, _T("BMP"), _T("*.BMP"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("位图文件(*.BMP;*.jpg;*.png)|*.BMP;*.jpg;*.png|"));
	if (IDOK == dlg.DoModal())
	{
		/*LPCTSTR path = (dlg.GetPathName());*/
		CString SaveFileName=dlg.m_ofn.lpstrFile;
		MyImage.dhSaveImage((SaveFileName));
		MessageBox(_T("保存成功"));
	}
	// TODO: 在此添加命令处理程序代码
}

// 将相应的图像进行反色处理
void CMFCView::OnColorBack()
{
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();

	byte* pDataImage = (byte*)MyImage.GetBits();

	int pitchImage = MyImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;

	int tmpR, tmpG, tmpB, avg;

	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			*(pDataImage + pitchImage * j + i * bitCountImage) = 255- *(pDataImage + pitchImage * j + i * bitCountImage);
		}
	}
	Invalidate();
	// 将原本的图像进行求反色
	// TODO: 在此添加命令处理程序代码
}

// 直方图均衡化的代码
void CMFCView::OnHistogram()
{
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();

	byte* pDataImage = (byte*)MyImage.GetBits();

	int pitchImage = MyImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;

	// 统计每种颜色出现的次数
	int GraySum = width * height;
	// 统计所有的像素个数
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			int var = *(pDataImage + pitchImage * j + i * bitCountImage);
			Gray[var]++;
		}
	}
	// 进行相应的转换
	for (int i = 0; i < 256; i++)
		GrayProb[i] = 1.0*Gray[i] / GraySum;
	GrayDistribution[0] = GrayProb[0];
	// 进行相应的累加操作
	for (int i = 1; i < 256; i++)
		GrayDistribution[i] += GrayDistribution[i - 1] + GrayProb[i];
	for (int i = 0; i < 256; i++)
		GrayEqual[i] = UCHAR(255 * GrayDistribution[i] + 0.5);
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			int var = *(pDataImage + pitchImage * j + i * bitCountImage	);
			*(pDataImage + pitchImage * j + i * bitCountImage) = GrayEqual[var];
		}
	}
	// 转换完成之后 ，进行相应的绘制操作。
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}

// 对应的参数计算方式
bool CMFCView::LogPicture(float c) {
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	MoveImage.Create(width, height, 8, 0);
	// 创建一个大小相同的画布
	byte* pDataImage = (byte*)MyImage.GetBits();
	byte* pDataMove = (byte*)MoveImage.GetBits();
	int pitchImage = MyImage.GetPitch();
	int pitchMove = MoveImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	int bitCountMove = MoveImage.GetBPP() / 8;
	// 统计每种颜色出现的次数
	int GraySum = width * height;
	// 对图像进行相应的绘制操作
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			int var = *(pDataImage + pitchImage * j + i * bitCountImage);
			*(pDataImage + pitchImage * j + i * bitCountImage) =min(255,UCHAR(c * log(1.0 + var) + 0.5));
			// 这个无论怎么变化 对应的结果都是在值域的
		}
	}
	// 转换完成之后 ，进行相应的绘制操作。
	Invalidate();
	return TRUE;
}

void CMFCView::OnLogTran()
{
	CLogPicture dlg;
	dlg.DoModal();
	// 生成相应的对话框函数
	float value = dlg.ValueC;
	LogPicture(value);
	MessageBox(_T("L对数化的结果"));
	// TODO: 在此添加命令处理程序代码
}

bool CMFCView::FactorPicture(float c, float r) {
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	// 创建一个大小相同的画布
	byte* pDataImage = (byte*)MyImage.GetBits();
	int pitchImage = MyImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	// 统计每种颜色出现的次数
	int GraySum = width * height;
	// 对图像进行相应的绘制操作
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			int var = *(pDataImage + pitchImage * j + i * bitCountImage);
			*(pDataImage + pitchImage * j + i * bitCountImage) = UCHAR(min(255,c*pow(1.0*var,r)));
			// 这个无论怎么变化 需要保证相应的图片是在其中的范围内部的
		}
	}
	// 转换完成之后 ，进行相应的绘制操作。
	Invalidate();
	return TRUE;
}

void CMFCView::OnFactor()
{
	CFactorPicture dlg;
	dlg.DoModal();
	float c = dlg.ValueC;
	float r = dlg.ValueR;
	FactorPicture(c, r);
	MessageBox(_T("绘制完成"));
	// TODO: 在此添加命令处理程序代码
}


void CMFCView::OnEqual()
{
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	CFilterSize dlg;
	dlg.DoModal();
	int value = dlg.ValueSize;
	// 进行相应的赋值操作
	filter.BuildEqual(value);
	CMatrix MatInput(MyImage,value);
	// 进行相应的赋值操作
	MatInput* filter;
	// 将相应的值进行相乘
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	MoveImage.Create(MyImage.GetWidth(), MyImage.GetHeight(), 8, 0);
	MatInput.WriteFile(MoveImage);

	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(MoveImage.GetWidth(), MoveImage.GetHeight(), 8, 0);
	ClRgbQuad ColorTab[256];
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	MyImage.SetColorTable(0, 256, ColorTab);
	int pitchImage = MyImage.GetPitch();
	int pitchMove = MoveImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	int bitCountMove = MoveImage.GetBPP() / 8;
	byte* pDataImage = (byte*)MyImage.GetBits();
	byte* pDataMove = (byte*)MoveImage.GetBits();
	for (int i = 0; i < width; i++)
		for (int j = 0; j < height; j++)
			*(pDataImage + pitchImage * j + i * bitCountImage) = *(pDataMove + pitchMove * j + i * bitCountMove);
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}


void CMFCView::OnBox()
{
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	CFilterSize dlg;
	dlg.DoModal();
	int value = dlg.ValueSize;
	// 进行相应的赋值操作
	filter.BuildSqure(value);
	CMatrix MatInput(MyImage, value);
	// 进行相应的赋值操作
	MatInput* filter;
	// 将相应的值进行相乘
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	MoveImage.Create(MyImage.GetWidth(), MyImage.GetHeight(), 8, 0);
	MatInput.WriteFile(MoveImage);

	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(MoveImage.GetWidth(), MoveImage.GetHeight(), 8, 0);

	ClRgbQuad ColorTab[256];
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	MyImage.SetColorTable(0, 256, ColorTab);
	int pitchImage = MyImage.GetPitch();
	int pitchMove = MoveImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	int bitCountMove = MoveImage.GetBPP() / 8;
	byte* pDataImage = (byte*)MyImage.GetBits();
	byte* pDataMove = (byte*)MoveImage.GetBits();
	for (int i = 0; i < width; i++)
		for (int j = 0; j < height; j++)
			*(pDataImage + pitchImage * j + i * bitCountImage) = *(pDataMove + pitchMove * j + i * bitCountMove);
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}

void CMFCView::FFT1(std::complex<double>* TD, std::complex<double>* FD, int r) {
	std::complex<double>* w1, * x1, * x2, * x;
	int count = 1 << r;
	w1 = new std::complex<double>[count / 2];
	x1 = new std::complex<double>[count];
	x2 = new std::complex<double>[count];

	for (int i = 0; i < count / 2; i++) {
		double angle = -1.0*i * PI * 2.0 / count;
		w1[i] = std::complex<double>(cos(angle), sin(angle));
	}

	int bfsize,p;
	memcpy(x1, TD, sizeof(std::complex<double>) * count);
	// 由于存在相应的编码问题 所以相应的求解公式存在不同
	// 所以我们就可以计算完成之后 将相应的结果进行变化即可
	for (int k = 0; k < r; k++) {
		// 分成r组 然后依次进行r次的迭代
		for (int j = 0; j < 1 << k; j++) {
			bfsize = 1 << (r - k);
			for (int i = 0; i < bfsize / 2; i++) {
				p = j * bfsize;
				// 采用的是未化简之前的形式	
				x2[i + p] = x1[i + p] + x1[i + p + bfsize / 2];// 这个本质上是偶数项数
				x2[i + p + bfsize / 2] = (x1[i + p] - x1[i + p + bfsize / 2]) * w1[i * (1 << k)];
			}
		}
		x = x1;
		x1 = x2;
		x2 = x;
	}

	
	//让其进行排序
	for (int j = 0; j < count; j++) {
		p = 0;
		for (int i = 0; i < r; i++) {
			if (j & (1 << i)) {
				p += 1 << (r - i - 1);
			}
		}
		FD[j] = x1[p];
	}
	// 释放相应的内存
	delete w1;
	delete x1;
	delete x2;
}
void CMFCView::IFFT1(std::complex<double>* FD, std::complex<double>* TD, int r) {
	std::complex<double>* x;
	int count = 1 << r;
	x = new std::complex<double>[count];
	memcpy(x, FD, sizeof(std::complex<double>) * count);
	for (int i = 0; i < count; i++)
		x[i] = std::complex<double>(x[i].real(), -x[i].imag());
	FFT1(x, TD, r);
	for (int i = 0; i < count; i++)
		TD[i] = std::complex<double>(TD[i].real() / count, -TD[i].imag() / count);
	delete x;
}
void CMFCView::FFT2(bool expand, BYTE color) {
	int w = 1;// 让其变成2的幂级数的形式 
	int h = 1;// 让其变成2的幂级数的形式
	int wp = 0;// 统计是多少次幂的形式
	int hp = 0;
	while (w * 2 <= MyImage.GetWidth()) {
		w *= 2;
		wp++;
	}
	while (h * 2 <= MyImage.GetHeight()) {
		h *= 2;
		hp++;
	}
	// 进行相应的扩展操作
	if ((expand) && (w <= MyImage.GetWidth()) && (h <= MyImage.GetHeight())) {
		w *= 2; wp++;
		h *= 2; hp++;
	}

	// 创建相应的颜色板
	ClRgbQuad ColorTab[256];
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	
	int pitchImage = MyImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	byte* pDataImage = (byte*)MyImage.GetBits();

	std::complex<double>* TD = new std::complex<double>[w * h];
	std::complex<double>* FD = new std::complex<double>[w * h];
	// 进行图像的赋值以及相应的填充操作

	for (int i = 0; i < h; i++) {
		// 注意相应的方向问题
		for (int j = 0; j < w; j++) {
			if (expand) {
				if (i < MyImage.GetHeight() && j < MyImage.GetWidth()) {
					TD[j * w + i] = std::complex<double>(*(pDataImage + pitchImage * i + j * bitCountImage), 0);
				}
				else {
					TD[j * w + i] = std::complex<double>(color, 0);
				}
			}
			else {
				TD[j * w + i] = std::complex<double>(*(pDataImage + pitchImage * i + j * bitCountImage), 0);
			}
		}
	}

	for (int i = 0; i < h; i++) {
		// 在y方向上进行相应的变化
		FFT1(&TD[w * i], &FD[w * i], wp);
	}
	// 对其进行相应的转置操作
	for (int i = 0; i < h; i++) {
		for (int j = 0; j < w; j++) {
			TD[i + h * j] = FD[j + w * i];
		}
	}
	// 
	for (int i = 0; i < w; i++) {
		// 在x方向上进行相应的变化
		FFT1(&TD[i * h], &FD[i * h], hp);
	}
	if (CInput!=nullptr) delete CInput;
	CInput = new std::complex<double>[w * h];
	for (int i = 0; i < h; i++) {
		for (int j = 0; j < w; j++) {
			CInput[i * w + j] = FD[j * h + i];
		}
	}
	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(w, h, 8, 0);
	pitchImage = MyImage.GetPitch();
	bitCountImage = MyImage.GetBPP() / 8;
	pDataImage = (byte*)MyImage.GetBits();
	MyImage.SetColorTable(0, 256, ColorTab);
	double dMax = 0, dMin = 1e6;
	for (int i = 0; i < h; i++) {
		for (int j = 0; j < w; j++) {
			double dTemp = sqrt(FD[j * h + i].real() * FD[j * h + i].real() + FD[j * h + i].imag() * FD[j * h + i].imag()) / 100;
			dTemp = log(dTemp + 1);
			dMax = max(dMax, dTemp);
			dMin = min(dMin, dTemp);
			// 不直接设置i和j 为了能够使得其中心在坐标原点
		}
	}

	for (int i = 0; i < h; i++) {
		for (int j = 0; j < w; j++) {
			double dTemp = sqrt(FD[j * h + i].real() * FD[j * h + i].real() + FD[j * h + i].imag() * FD[j * h + i].imag()) / 100;
			dTemp = log(dTemp + 1);
			dTemp = (dTemp - dMin) / (dMax - dMin) * 255;
			// 不直接设置i和j 为了能够使得其中心在坐标原点
			*(pDataImage + pitchImage * (j < w / 2 ? j + w / 2 : j - w / 2) + (i < h / 2 ? i + h / 2 : i - h / 2) * bitCountImage) = dTemp;
		}
	}

	delete TD;
	delete FD;
}
// 进行相应的高斯变化


// 对应的输入和输出是相同的
void CMFCView::IFFT2(int lWidth, int lHeight) {
	int w = 1;
	int h = 1;
	int wp = 0;
	int hp = 0;// 进行相应的初始化操作
	while (w * 2 <= lWidth) {
		w *= 2;
		wp++;
	}// 保证相应的是2次方的图像大小
	while (h * 2 <= lHeight) {
		h *= 2;
		hp++;
	}

	std::complex<double>* TD = new std::complex<double>[w*h];
	std::complex<double>* FD = new std::complex<double>[w * h];

	// 生成相应大小的图像
	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(lWidth, lHeight,8,0);
	ClRgbQuad ColorTab[256];
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	MyImage.SetColorTable(0, 256, ColorTab);
	int pitchImage = MyImage.GetPitch();
	byte* pDataImage = (byte*)MyImage.GetBits();
	int bitCountImage = MyImage.GetBPP() / 8;
	// 生成相应的图像 方便进行相应的操作
	for (int i = 0; i < h; i++) {
		for (int j = 0; j < w; j++) {
			FD[j + w * i] = CInput[j + w * i];
		}
	}
	for (int i = 0; i < h; i++) {
		// 对y方向进行相应的快速逆傅里叶变化
		IFFT1(&FD[w * i], &TD[w * i], wp);
	}

	for (int i = 0; i < h; i++) {
		for (int j = 0; j < w; j++) {
			FD[i + j * h] = TD[j+w*i];
		}
	}
	// 对x方向进行相应的变化
	for (int i = 0; i < w; i++) {
		IFFT1(&FD[h * i], &TD[h * i], hp);
	}
	double dMax = 0, dMin = 1e6;
	for (int i = 0; i < lHeight; i++) {
		for (int j = 0; j < lWidth; j++) {
			double  dTemp = sqrt(TD[j * h + i].real() * TD[j * h + i].real() + TD[j * h + i].imag() * TD[j + h + i].imag());
			dMax = max(dMax, dTemp);
			dMin = min(dMin, dTemp);
		}
	}
	for (int i = 0; i < lHeight; i++) {
		for (int j = 0; j < lWidth; j++) {
			double  dTemp = sqrt(TD[j * h + i].real() * TD[j * h + i].real() + TD[j * h + i].imag() * TD[j + h + i].imag());
			// 这样的话 就不需要进行相应的取log运算了
			dTemp = (dTemp - dMin) / (dMax - dMin) * 255;
			*(pDataImage + pitchImage*j + bitCountImage*i) = dTemp;
		}
	}

}

// 对应的高斯滤波
void CMFCView::OnGauss()
{
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	CFilterSize dlg;
	dlg.DoModal();
	int value = dlg.ValueSize;
	int Sigma = dlg.ValueSigma;
	// 进行相应的赋值操作
	filter.BuildGauss(value,Sigma);
	CMatrix MatInput(MyImage, value);
	// 进行相应的赋值操作
	MatInput* filter;
	// 将相应的值进行相乘
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	MoveImage.Create(MyImage.GetWidth(), MyImage.GetHeight(), 8, 0);
	MatInput.WriteFile(MoveImage);

	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(MoveImage.GetWidth(), MoveImage.GetHeight(), 8, 0);
	ClRgbQuad ColorTab[256];
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	MyImage.SetColorTable(0, 256, ColorTab);
	int pitchImage = MyImage.GetPitch();
	int pitchMove = MoveImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	int bitCountMove = MoveImage.GetBPP() / 8;
	byte* pDataImage = (byte*)MyImage.GetBits();
	byte* pDataMove = (byte*)MoveImage.GetBits();
	for (int i = 0; i < width; i++)
		for (int j = 0; j < height; j++)
			*(pDataImage + pitchImage * j + i * bitCountImage) = *(pDataMove + pitchMove * j + i * bitCountMove);
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}

// 拉普拉斯滤波
void CMFCView::OnLaplace()
{
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	CFilterSize dlg;
	dlg.DoModal();
	// 打开相应的值
	int value = dlg.ValueSize;
	int valueC = dlg.ValueSigma;
	int pitchImage = MyImage.GetPitch();
	byte* pDataImage = (byte*)MyImage.GetBits();
	int bitCountImage = MyImage.GetBPP() / 8;
	
	// 这边是生成相应的图像
	if (!GrayImage.IsNull()) GrayImage.Destroy();
	GrayImage.Create(width, height, 8, 0);
	ClRgbQuad ColorTab[256];
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	GrayImage.SetColorTable(0, 256, ColorTab);
	int pitchGray = GrayImage.GetPitch();
	int bitCountGray = GrayImage.GetBPP() / 8;
	byte* pDataGray = (byte*)GrayImage.GetBits();
	for (int i = 0; i < width; i++) 
		for(int j=0;j<height;j++)
			*(pDataGray + pitchGray * j + i * bitCountGray) = *(pDataImage + pitchImage * j + i * bitCountImage);

	// 新建相应的laplace矩阵
	filter.BuildLaplace(value);
	CMatrix MatInput(MyImage, 1);
	// 创建相应的边沿 本质上是因为其出现了问题
	// 进行相应的赋值操作
	MatInput* filter;
	// 将相应的值进行相乘
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	MoveImage.Create(MyImage.GetWidth(), MyImage.GetHeight(), 8, 0);
	MoveImage.SetColorTable(0, 256, ColorTab);
	MatInput.WriteFile(MoveImage);

	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(MoveImage.GetWidth(), MoveImage.GetHeight(), 8, 0);
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	MyImage.SetColorTable(0, 256, ColorTab);

	pitchImage = MyImage.GetPitch();
	pDataImage = (byte*)MyImage.GetBits();
	bitCountImage = MyImage.GetBPP() / 8;
	int pitchMove = MoveImage.GetPitch();
	int bitCountMove = MoveImage.GetBPP() / 8;
	byte* pDataMove = (byte*)MoveImage.GetBits();
	int sum = 0;

	//for (int i = 0; i < width; i++) {
	//	for (int j = 0; j < height; j++) {
	//		*(pDataImage + pitchImage * j + i * bitCountImage) = *(pDataMove + pitchMove * j + i * bitCountMove);
	//	}
	//}
	for (int i = 0; i < width; i++)
		for (int j = 0; j < height; j++) {
			*(pDataImage + pitchImage * j + i * bitCountImage) = max(0,min(255,*(pDataMove + pitchMove * j + i * bitCountMove)*valueC+*(pDataGray+pitchGray*j+i*bitCountGray)));
		}/*min(255,*(pDataMove + pitchMove * j + i * bitCountMove)*valueC+ **/
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}

// 这个是不需要设置相应的函数核的
// 设置相应的高提升滤波

void CMFCView::OnHighFilter()
{
	CFilterSize dlg;
	dlg.DoModal();
	int value = dlg.ValueSigma;
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	// 如果是空的话 就进行相应的删除操作
	if (!GrayImage.IsNull()) GrayImage.Destroy();
	GrayImage.Create(width, height, 8, 0);
	ClRgbQuad ColorTab[256];

	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	GrayImage.SetColorTable(0, 256, ColorTab);

	int pitchImage = MyImage.GetPitch();
	byte* pDataImage = (byte*)MyImage.GetBits();
	int bitCountImage = MyImage.GetBPP() / 8;

	int pitchGray = GrayImage.GetPitch();
	int bitCountGray = GrayImage.GetBPP() / 8;
	byte* pDataGray = (byte*)GrayImage.GetBits();
	// 进行相应的复制操作
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			*(pDataGray + pitchGray * j + i * bitCountGray) = *(pDataImage + pitchImage * j + i * bitCountImage);
		}
	}
	OnGauss();
	
	pitchImage = MyImage.GetPitch();
	pDataImage = (byte*)MyImage.GetBits();
	bitCountImage = MyImage.GetBPP() / 8;
	// 高斯处理之后的结果
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			// 从而实现相应的放大效果
			*(pDataImage + pitchImage * j + i * bitCountImage) = max(0,min(255,value * (*(pDataGray + pitchGray * j + i * bitCountGray) - *(pDataImage + pitchImage * j + i * bitCountImage)) + *(pDataGray + pitchGray * j + i * bitCountGray)));
		}
	}
	Invalidate();
	// 这个操作之后 对应的MyImage是高斯处理后的
	
	// TODO: 在此添加命令处理程序代码
}

void CMFCView::BuildIdea(int height,int width,int nFreq) {
	if (CFilter != nullptr) delete CFilter;
	CFilter = new std::complex<double>[width * height];
	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			if (sqrt(pow(i - height / 2.0, 2) + pow(j - width / 2.0, 2)) > nFreq) {
				CFilter[(i < height / 2 ? i + height / 2 : i - height / 2) * width + (j < width / 2 ? j + width / 2 : j - width / 2)] = 0;
			}
			else {
				CFilter[(i < height / 2 ? i + height / 2 : i - height / 2) * width + (j < width / 2 ? j + width / 2 : j - width / 2)] = 1;
			}
		}
	}
}
void CMFCView::OnIdeaLower()
{
	CFilterSigma dlg;
	dlg.DoModal();
	double value = dlg.ValueSigma;
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	FFT2(0, 1);
	// 创建一个半径为3的理想滤波器
	BuildIdea(height, width, value);
	for (int i = 0; i < width * height; i++) {
		CInput[i] = CInput[i] * CFilter[i];
	}
	IFFT2(width,height);
	Invalidate();
}

// 生成相应的高斯核
void CMFCView::BuildGauss(int height, int width, double sigma) {
	if (CFilter != nullptr) delete CFilter;
	CFilter = new std::complex<double>[width * height];
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < width; j++) {
			CFilter[(i < height / 2 ? i + height / 2 : i - height / 2) * width + (j < width / 2 ? j + width / 2 : j - width / 2)] = exp(-(pow(i-height/2.0,2)+pow(j-width/2.0,2))/2/pow(sigma,2));
		}
	}
}

void CMFCView::BuildHIdea(int height, int width, int nFreq) {
	if (CFilter != nullptr) delete CFilter;
	CFilter = new std::complex<double>[width * height];
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			if (sqrt(pow(i - height / 2.0, 2) + pow(j - width / 2.0, 2)) > nFreq) {
				CFilter[(i < height / 2 ? i + height / 2 : i - height / 2) * width + (j < width / 2 ? j + width / 2 : j - width / 2)] = 1;
			}
			else {
				CFilter[(i < height / 2 ? i + height / 2 : i - height / 2) * width + (j < width / 2 ? j + width / 2 : j - width / 2)] = 0;
			}
		}
	}
}
void CMFCView::OnGaussLower()
{
	CFilterSigma dlg;
	dlg.DoModal();
	double value = dlg.ValueSigma;
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	FFT2(0, 1);
	// 创建一个半径为3的理想滤波器
	BuildGauss(height, width, value);
	for (int i = 0; i < width * height; i++) {
		CInput[i] = CInput[i] * CFilter[i];
	}
	IFFT2(width, height);
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}


void CMFCView::OnIdeaHigher()
{
	CFilterSigma dlg;
	dlg.DoModal();
	double value = dlg.ValueSigma;
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	FFT2(0, 1);
	// 创建一个半径为3的理想滤波器
	BuildHIdea(height, width, value);
	for (int i = 0; i < width * height; i++) {
		CInput[i] = CInput[i] * CFilter[i];
	}
	IFFT2(width, height);
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}

void CMFCView::BuildHGauss(int height, int width, double sigma) {

	if (CFilter != nullptr) delete CFilter;
	CFilter = new std::complex<double>[width * height];
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			CFilter[(i < height / 2 ? i + height / 2 : i - height / 2) * width + (j < width / 2 ? j + width / 2 : j - width / 2)] = 1-exp(-(pow(i - height / 2.0, 2) + pow(j - width / 2.0, 2)) / 2 / pow(sigma, 2));
		}
	}
}

void CMFCView::OnGaussHigher()
{
	CFilterSigma dlg;
	dlg.DoModal();
	double value = dlg.ValueSigma;
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	FFT2(0, 1);
	// 创建一个半径为3的理想滤波器
	BuildHGauss(height, width, value);
	for (int i = 0; i < width * height; i++) {
		CInput[i] = CInput[i] * CFilter[i];
	}
	IFFT2(width, height);
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}


void CMFCView::BuildBt(int height, int width, double dSigma, int n) {

	if (CFilter != nullptr) delete CFilter;
	CFilter = new std::complex<double>[width * height];
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			CFilter[(i < height / 2 ? i + height / 2 : i - height / 2) * width + (j < width / 2 ? j + width / 2 : j - width / 2)] = 1 / (1 + pow(sqrt(pow(i - height / 2.0, 2) + pow(j - width / 2.0, 2))/(dSigma), 2 * n));
		}
	}
}

void CMFCView::BuildHBt(int height, int width, double dSigma, int n) {

	if (CFilter != nullptr) delete CFilter;
	CFilter = new std::complex<double>[width * height];
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			CFilter[(i < height / 2 ? i + height / 2 : i - height / 2) * width + (j < width / 2 ? j + width / 2 : j - width / 2)] = 1 - 1.0 / (1 + pow(sqrt(pow(i - height / 2.0, 2) + pow(j - width / 2.0, 2))/dSigma, 2 * n));
		}
	}
}

void CMFCView::OnBlower()
{
	CFilterSize dlg;
	dlg.DoModal();
	int valueN = dlg.ValueSize;
	double value = dlg.ValueSigma;
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	FFT2(0, 1);
	// 创建一个半径为3的理想滤波器
	BuildBt(height, width, value,valueN);
	for (int i = 0; i < width * height; i++) {
		CInput[i] = CInput[i] * CFilter[i];
	}
	IFFT2(width, height);
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}


void CMFCView::OnBhigher()
{
	CFilterSize dlg;
	dlg.DoModal();
	int valueN = dlg.ValueSize;
	double value = dlg.ValueSigma;
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	FFT2(0, 1);
	// 创建一个半径为3的理想滤波器
	BuildHBt(height, width, value, valueN);
	for (int i = 0; i < width * height; i++) {
		CInput[i] = CInput[i] * CFilter[i];
	}
	IFFT2(width, height);
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}


void CMFCView::OnGradx()
{
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	CMatrix TempMatrix(MyImage,1);
	ClRgbQuad ColorTab[256];
	// 这是在绑定相应的色板
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	TempMatrix.gradFx(MyImage);
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	MoveImage.Create(width, height, 8, 0);

	MoveImage.SetColorTable(0, 256, ColorTab);

	TempMatrix.WriteFile(MoveImage);
	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(width, height, 8, 0);
	int pitchImage = MyImage.GetPitch();
	int pitchMove = MoveImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	int bitCountMove = MoveImage.GetBPP() / 8;
	byte* pDataImage = (byte*)MyImage.GetBits();
	byte* pDataMove = (byte*)MoveImage.GetBits();

	MyImage.SetColorTable(0, 256, ColorTab);
	// 将未被旋转的区域置为白色

	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			*(pDataImage + pitchImage * j + i * bitCountMove) = *((pDataMove + pitchMove * j + i * bitCountMove));
		}
	}
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}


void CMFCView::OnGrady()
{
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	CMatrix TempMatrix(MyImage, 1);
	ClRgbQuad ColorTab[256];
	// 这是在绑定相应的色板
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	TempMatrix.gradFy(MyImage);
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	MoveImage.Create(width, height, 8, 0);

	MoveImage.SetColorTable(0, 256, ColorTab);

	TempMatrix.WriteFile(MoveImage);
	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(width, height, 8, 0);
	int pitchImage = MyImage.GetPitch();
	int pitchMove = MoveImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	int bitCountMove = MoveImage.GetBPP() / 8;
	byte* pDataImage = (byte*)MyImage.GetBits();
	byte* pDataMove = (byte*)MoveImage.GetBits();

	MyImage.SetColorTable(0, 256, ColorTab);
	// 将未被旋转的区域置为白色

	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			*(pDataImage + pitchImage * j + i * bitCountMove) = *((pDataMove + pitchMove * j + i * bitCountMove));
		}
	}
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}


void CMFCView::OnGradsum()
{
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	CMatrix TempMatrix(MyImage, 1);
	ClRgbQuad ColorTab[256];
	// 这是在绑定相应的色板
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	TempMatrix.gradSum(MyImage);
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	MoveImage.Create(width, height, 8, 0);

	MoveImage.SetColorTable(0, 256, ColorTab);

	TempMatrix.WriteFile(MoveImage);
	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(width, height, 8, 0);
	int pitchImage = MyImage.GetPitch();
	int pitchMove = MoveImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	int bitCountMove = MoveImage.GetBPP() / 8;
	byte* pDataImage = (byte*)MyImage.GetBits();
	byte* pDataMove = (byte*)MoveImage.GetBits();

	MyImage.SetColorTable(0, 256, ColorTab);
	// 将未被旋转的区域置为白色

	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			*(pDataImage + pitchImage * j + i * bitCountMove) = *((pDataMove + pitchMove * j + i * bitCountMove));
		}
	}
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}

// 采用这种方式进行相应的边缘提取的方式
void CMFCView::OnLogEdge()
{
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	CFilterSize dlg;
	dlg.DoModal();
	int value = dlg.ValueSize;
	int Sigma = dlg.ValueSigma;
	// 进行相应的赋值操作
	filter.BuildLog(value, Sigma);
	CMatrix MatInput(MyImage, value);
	// 进行相应的赋值操作
	MatInput* filter;


	// 将相应的值进行相乘
	if (!MoveImage.IsNull()) MoveImage.Destroy();
	MoveImage.Create(MyImage.GetWidth(), MyImage.GetHeight(), 8, 0);

	MatInput.zerosJudge();// 判断相应的零交点
	MatInput.WriteFile(MoveImage);

	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(MoveImage.GetWidth(), MoveImage.GetHeight(), 8, 0);
	ClRgbQuad ColorTab[256];
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
	MyImage.SetColorTable(0, 256, ColorTab);
	int pitchImage = MyImage.GetPitch();
	int pitchMove = MoveImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	int bitCountMove = MoveImage.GetBPP() / 8;
	byte* pDataImage = (byte*)MyImage.GetBits();
	byte* pDataMove = (byte*)MoveImage.GetBits();
	for (int i = 0; i < width; i++)
		for (int j = 0; j < height; j++)
			*(pDataImage + pitchImage * j + i * bitCountImage) = *(pDataMove + pitchMove * j + i * bitCountMove);
	Invalidate();
	// TODO: 在此添加命令处理程序代码

}

// 获取相应的角度
double CMFCView::getAngle(int i, int j) {
	int pitchy = Sobely.GetPitch();
	int pitchx = Sobelx.GetPitch();
	int bitCounty = Sobely.GetBPP() / 8;
	int bitCountx = Sobelx.GetBPP() / 8;
	byte* pDatay = (byte*)Sobely.GetBits();
	byte* pDatax = (byte*)Sobelx.GetBits();
	double vary = 1.0 * (*(pDatay + pitchy * j + i * bitCounty));
	double varx = 1.0 * (*(pDatax + pitchx * j + i * bitCountx));

	return (atan(vary / (varx+1e-6))) / PI * 180+90;
	//return (atan(1.0* )/()+PI/2))/PI*180;
}

// 采用canny算法去进行相应的实现操作

// 这个是展示相应的sobelxy的结果
//void CMFCView::OnCannyEdge() {
//	int width = MyImage.GetWidth();
//	int height = MyImage.GetHeight();
//	ClRgbQuad ColorTab[256];
//	for (int i = 0; i < 256; i++)
//		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
//	Matrix MatInput(MyImage);
//	MatInput.SobelSum(MyImage);
//	if (!MoveImage.IsNull()) MoveImage.Destroy();
//	MoveImage.Create(width, height, 8, 0);
//
//	MoveImage.SetColorTable(0, 256, ColorTab);
//
//	MatInput.WriteFile(MoveImage);
//	if (!MyImage.IsNull()) MyImage.Destroy();
//	MyImage.Create(width, height, 8, 0);
//	int pitchImage = MyImage.GetPitch();
//	int pitchMove = MoveImage.GetPitch();
//	int bitCountImage = MyImage.GetBPP() / 8;
//	int bitCountMove = MoveImage.GetBPP() / 8;
//	byte* pDataImage = (byte*)MyImage.GetBits();
//	byte* pDataMove = (byte*)MoveImage.GetBits();
//
//	MyImage.SetColorTable(0, 256, ColorTab);
//	// 将未被旋转的区域置为白色
//
//	for (int i = 0; i < height; i++) {
//		for (int j = 0; j < width; j++) {
//			*(pDataImage + pitchImage * j + i * bitCountMove) = *((pDataMove + pitchMove * j + i * bitCountMove));
//		}
//	}
//	Invalidate();
//}

//void CMFCView::OnCannyEdge()
//{
//	// TODO: 在此添加命令处理程序代码
//
//	int width = MyImage.GetWidth();
//	int height = MyImage.GetHeight();
//	ClRgbQuad ColorTab[256];
//	for (int i = 0; i < 256; i++)
//		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;
//	// 进行相应的赋值操作
//
//	filter.BuildGauss(2, 1);
//	Matrix MatInput(MyImage, 2);
//	// 进行相应的赋值操作
//	MatInput* filter;
//	// 将相应的值进行相乘
//	// 进行相应的gauss操作 对应的结果存储在output中
//	//// 采用的是sobel算子去计算相应的幅值和方向
//	if (!MoveImage.IsNull()) MoveImage.Destroy();
//	MoveImage.Create(MyImage.GetWidth(), MyImage.GetHeight(), 8, 0);
//	MoveImage.SetColorTable(0, 256, ColorTab);
//	MatInput.WriteFile(MoveImage);
//
//	//filter.BuildSobelx();
//	//MatInput* filter;
//	MatInput.setMatrix(MoveImage);
//	MatInput.SobelX(MoveImage);
//
//	if (!Sobelx.IsNull()) Sobelx.Destroy();
//	Sobelx.Create(MyImage.GetWidth(), MyImage.GetHeight(), 8, 0);
//	Sobelx.SetColorTable(0, 256, ColorTab);
//	MatInput.WriteFile(Sobelx);
//
//	//filter.BuildSobely();
//	////MatInput.setMatrix(MoveImage);
//	//MatInput* filter;
//
//	MatInput.setMatrix(MoveImage);
//	MatInput.SobelY(MoveImage);
//	if (!Sobely.IsNull()) Sobely.Destroy();
//	Sobely.Create(MyImage.GetWidth(), MyImage.GetHeight(), 8, 0);
//	Sobely.SetColorTable(0, 256, ColorTab);
//	MatInput.WriteFile(Sobely);
//	MatInput.setMatrix(MoveImage);
//	MatInput.SobelSum(MoveImage);
//	
//	if (!SobelSum.IsNull()) SobelSum.Destroy();
//	SobelSum.Create(MyImage.GetWidth(), MyImage.GetHeight(), 8, 0);
//	SobelSum.SetColorTable(0, 256, ColorTab);
//	MatInput.WriteFile(SobelSum);
//
//	int pitchSum = SobelSum.GetPitch();
//	int bitCountSum = SobelSum.GetBPP() / 8;
//	byte* pDataSum = (byte*)SobelSum.GetBits();
//
//	////// 对应的输出图像
//	if (!MyImage.IsNull()) MyImage.Destroy();
//	MyImage.Create(MoveImage.GetWidth(), MoveImage.GetHeight(), 8, 0);
//	MyImage.SetColorTable(0, 256, ColorTab);
//	int pitchImage = MyImage.GetPitch();
//	int bitCountImage = MyImage.GetBPP() / 8;
//	byte* pDataImage = (byte*)MyImage.GetBits();
//
//	int pitchx = Sobelx.GetPitch();
//	int bitCountx = Sobelx.GetBPP() / 8;
//	byte* pDatax = (byte*)Sobelx.GetBits();
//
//	int pitchy = Sobely.GetPitch();
//	int bitCounty = Sobely.GetBPP() / 8;
//	byte* pDatay = (byte*)Sobely.GetBits();
//
//	int k = 0;
//	int MAX = 0;
//
//
//	 //计算完毕之后 在进行相应的计算
//	for (int i = 1; i < height-1; i++) {
//		for (int j = 1; j < width-1; j++) {
//			int var = *(pDataSum + pitchSum * j + i * bitCountSum);
//			double grad1, grad2,grad3,grad4,w=0;
//			if (var == 0) {
//				*(pDataImage + pitchImage * j + i * bitCountImage) = 0;
//			}
//			else {
//				int varx = *(pDatax + pitchx * j + i * bitCountx);
//				int vary = *(pDatay + pitchy * j + i * bitCounty);
//				if (abs(vary) > abs(varx)) {
//					w = 1.0*abs(varx) / abs(vary+1e-10);
//					grad2 = *(pDataSum + pitchSum * j + (i - 1) * bitCountSum);
//					grad4 = *(pDataSum + pitchSum * j + (i + 1) * bitCountSum);
//					if ( varx* vary > 0) {
//						grad1= *(pDataSum + pitchSum * (j-1) + (i - 1) * bitCountSum);
//						grad3 = *(pDataSum + pitchSum * (j + 1) + (i + 1) * bitCountSum);
//					}
//					else {
//						grad1 = *(pDataSum + pitchSum * (j + 1) + (i - 1) * bitCountSum);
//						grad3 = *(pDataSum + pitchSum * (j - 1) + (i + 1) * bitCountSum);
//					}
//				}
//				else {
//					w =1.0* abs(vary) / abs(varx+1e-10);
//					grad2 = *(pDataSum + pitchSum * (j-1) + i * bitCountSum);
//					grad4 = *(pDataSum + pitchSum * (j+1) + i * bitCountSum);
//					if (varx * vary> 0) {
//						grad1 = *(pDataSum + pitchSum * (j - 1) + (i + 1) * bitCountSum);
//						grad3 = *(pDataSum + pitchSum * (j + 1) + (i - 1) * bitCountSum);
//					}
//					else {
//						grad1 = *(pDataSum + pitchSum * (j - 1) + (i - 1) * bitCountSum);
//						grad3 = *(pDataSum + pitchSum * (j + 1) + (i + 1) * bitCountSum);
//					}
//				}
//				int gradTemp1 = w * grad1 + (1 - w) * grad2+0.5;
//				int gradTemp2 = w * grad3 + (1 - w) * grad4+0.5;
//				if (var >= gradTemp1 && var >= gradTemp2) {
//					*(pDataImage + pitchImage * j + i * bitCountImage) = var;
//					MAX = max(MAX, var);
//				}
//				else
//					*(pDataImage + pitchImage * j + i * bitCountImage) = 0;
//			}
//			
//		}
//	}
//	
//	//// 采用角度的方式进行计算
//	//for (int i = 1; i < width - 1; i++) {
//	//	for (int j = 1; j < height - 1; j++) {
//	//		int var = *(pDataSum + pitchSum * j + i * bitCountSum);
//	//		// 获得相应的值
//	//		int grad1, grad2, grad3, grad4, w = 0;
//	//		if (var == 0) 
//	//			*(pDataImage + pitchImage * j + i * bitCountImage) = 0;
//	//		else {
//	//			int varx = *(pDatax + pitchx * j + i * bitCountx);
//	//			int vary = *(pDatay + pitchy * j + i * bitCounty);
//	//			// 分别获得x和y方向上的梯度值
//	//			double angle = (atan2(vary, varx)) / PI * 180;
//	//			if (angle < 0) angle += 360;
//	//			if ((angle <= 22.5 && angle >= 0) || angle >= 337.5) {
//	//				grad1 = *(pDataSum + pitchSum * (j - 1) + i * bitCountSum);;
//	//				grad2= *(pDataSum + pitchSum * (j + 1) + i * bitCountSum);
//	//			}
//	//			else if ((angle <= 67.5 && angle > 22.5) || (angle <= 337.5 && angle > 292.5)) {
//	//				grad1 = *(pDataSum + pitchSum * (j + 1) + (i-1) * bitCountSum);
//	//				grad2 = *(pDataSum + pitchSum * (j - 1) + (i+1) * bitCountSum);
//	//			}
//	//			else if ((angle <= 112.5 && angle > 67.5) || (angle <= 292.5 && angle > 247.5)) {
//	//				grad1 = *(pDataSum + pitchSum * j + (i - 1) * bitCountSum);
//	//				grad2 = *(pDataSum + pitchSum * j + (i + 1) * bitCountSum);
//	//			}
//	//			else if ((angle <= 157.5 && angle > 112.5) || (angle <= 247.5 && angle > 202.5)) {
//	//				grad1 = *(pDataSum + pitchSum * (j-1) + (i - 1) * bitCountSum);
//	//				grad2 = *(pDataSum + pitchSum * (j+1) + (i + 1) * bitCountSum);
//	//			}
//	//			else {
//	//				grad1 = *(pDataSum + pitchSum * (j - 1) + i* bitCountSum);
//	//				grad2 = *(pDataSum + pitchSum * (j + 1) + i * bitCountSum);
//	//			}
//
//	//			if(var<grad1||var<grad2)
//	//				*(pDataImage + pitchImage * j + i * bitCountImage) = 0;
//	//			else {
//	//				*(pDataImage + pitchImage * j + i * bitCountImage) = var;
//	//				MAX = max(MAX, var);
//	//			}
//	//		}
//	//	}
//	//}
//	
//	// 先暂时存放在MoveImage中
//	if (!MoveImage.IsNull()) MoveImage.Destroy();
//	MoveImage.Create(width, height, 8, 0);
//	MoveImage.SetColorTable(0, 256, ColorTab);
//
//	byte* pDataMove = (byte*)MoveImage.GetBits();
//	int pitchMove = MoveImage.GetPitch();
//	int bitCountMove = MoveImage.GetBPP() / 8;
//
//	//// 双阈值算法检测边缘
//	double TL =20;
//	double TH = 60;
//	for (int i = 1; i < height - 1; i++) {
//		for (int j = 1; j < width - 1; j++) {
//			int var = *(pDataImage + pitchImage * j + i * bitCountImage);
//			if (var < TL)
//				*(pDataMove + pitchMove * j + i * bitCountMove) = 0;
//			else if (var > TH)
//				*(pDataMove + pitchMove * j + i * bitCountMove) =255;
//			else {
//				int g1 = *(pDataImage + pitchImage * j + (i-1) * bitCountImage);
//				int g2= *(pDataImage + pitchImage * (j-1) + (i-1) * bitCountImage);
//				int g3 = *(pDataImage + pitchImage * (j+1) + (i-1) * bitCountImage);
//				int g4 = *(pDataImage + pitchImage * (j-1) + i * bitCountImage);
//				int g5 = *(pDataImage + pitchImage * (j+1) + i * bitCountImage);
//				int g6 = *(pDataImage + pitchImage * j + (i+1) * bitCountImage);
//				int g7 = *(pDataImage + pitchImage * (j-1) + (i+1) * bitCountImage);
//				int g8 = *(pDataImage + pitchImage * (j+1) + (i+1) * bitCountImage);
//				if (g1>TH||g2>TH||g3>TH||g4>TH||g5>TH||g6>TH||g7>TH||g8>TH)
//					*(pDataMove + pitchMove * j + i * bitCountMove) = 255;
//			}
//		}
//	}
//	if (!MyImage.IsNull()) MyImage.Destroy();
//	MyImage.Create(width, height, 8, 0);
//	MyImage.SetColorTable(0, 256, ColorTab);
//
//	for (int i = 0; i < width; i++) {
//		for (int j = 0; j < height; j++) {
//			*(pDataImage + pitchImage * j + i * bitCountImage) = *(pDataMove + pitchMove * j + i * bitCountMove);
//		}
//	}
//	
//	Invalidate();
//}

// 进行canny

void CMFCView::OnCannyEdge() {

	CCannyEdge dlg;
	dlg.DoModal();

	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	ClRgbQuad ColorTab[256];
	for (int i = 0; i < 256; i++)
		ColorTab[i].rgbBlue = ColorTab[i].rgbGreen = ColorTab[i].rgbRed = i;

	CMatrix MatInput(MyImage, 2);
	filter.BuildGauss(2, 1);
	MatInput* filter;
	if (!GrayImage.IsNull()) GrayImage.Destroy();
	GrayImage.Create(width, height, 8, 0);
	GrayImage.SetColorTable(0, 256, ColorTab);
	MatInput.WriteFile(GrayImage);
	// 其中GrayImage表示的是做完高斯变化的结果

	if (!Sobelx.IsNull()) Sobelx.Destroy();
	Sobelx.Create(width - 1, height - 1, 8, 0);
	Sobelx.SetColorTable(0, 256, ColorTab);

	if (!Sobely.IsNull()) Sobely.Destroy();
	Sobely.Create(width - 1, height - 1, 8, 0);
	Sobely.SetColorTable(0, 256, ColorTab);

	if (!SobelSum.IsNull()) SobelSum.Destroy();
	SobelSum.Create(width - 1, height - 1, 8, 0);
	SobelSum.SetColorTable(0, 256, ColorTab);

	int pitchy = Sobely.GetPitch();
	int pitchx = Sobelx.GetPitch();
	int pitchSum = SobelSum.GetPitch();
	int pitchGray = GrayImage.GetPitch();
	int bitCounty = Sobely.GetBPP() / 8;
	int bitCountx = Sobelx.GetBPP() / 8;
	int bitCountSum = SobelSum.GetBPP() / 8;
	int bitCountGray = GrayImage.GetBPP() / 8;
	byte* pDatay = (byte*)Sobely.GetBits();
	byte* pDatax = (byte*)Sobelx.GetBits();
	byte* pDataSum = (byte*)SobelSum.GetBits();
	byte* pDataGray = (byte*)GrayImage.GetBits();

	// 计算相应的梯度方向
	for (int i = 1; i < width - 1; i++) {
		for (int j = 1; j < height - 1; j++) {
			// 其中x的分布
			int valuex00 = *(pDataGray + pitchGray * (j - 1) + (i - 1) * bitCountGray);
			int valuex01 = *(pDataGray + pitchGray * (j - 1) + i * bitCountGray);
			int valuex02 = *(pDataGray + pitchGray * (j - 1) + (i + 1) * bitCountGray);
			int valuex20 = *(pDataGray + pitchGray * (j + 1) + (i - 1) * bitCountGray);
			int valuex21 = *(pDataGray + pitchGray * (j + 1) + i * bitCountGray);
			int valuex22 = *(pDataGray + pitchGray * (j + 1) + (i + 1) * bitCountGray);
			// 其中y的分布
			int valuey00 = *(pDataGray + pitchGray * (j - 1) + (i - 1) * bitCountGray);
			int valuey01 = *(pDataGray + pitchGray * j + (i - 1) * bitCountGray);
			int valuey02 = *(pDataGray + pitchGray * (j + 1) + (i - 1) * bitCountGray);
			int valuey20 = *(pDataGray + pitchGray * (j - 1) + (i + 1) * bitCountGray);
			int valuey21 = *(pDataGray + pitchGray * j + (i + 1) * bitCountGray);
			int valuey22 = *(pDataGray + pitchGray * (j + 1) + (i + 1) * bitCountGray);
			int valuex = valuex00 + 2 * valuex01 + valuex02 - valuex20 - 2 * valuex21 - valuex22;
			int valuey = valuey00 + 2 * valuey01 + valuey02 - valuey20 - 2 * valuey21 - valuey22;
			*(pDatax + pitchx * j + i * bitCountx) = valuex;
			*(pDatay + pitchy * j + i * bitCounty) = valuey;
			*(pDataSum + pitchSum * j + i * bitCountSum) = sqrt(valuex * valuex + valuey * valuey);
		}
	}

	if (!MoveImage.IsNull()) MoveImage.Destroy();
	MoveImage.Create(width - 1, height - 1, 8, 0);
	MoveImage.SetColorTable(0, 256, ColorTab);

	byte* pDataMove = (byte*)MoveImage.GetBits();
	int pitchMove = MoveImage.GetPitch();
	int bitCountMove = MoveImage.GetBPP() / 8;
	// 非极大值抑制

	for (int i = 1; i < width - 2; i++) {
		for (int j = 1; j < height -2; j++) {
			int d = *(pDataSum + pitchSum * j + i * bitCountSum);
			if (d == 0) {
				*(pDataMove + pitchMove * j + i * bitCountMove) = 0;
			}
			else {
				int g1 = 0;
				int g2 = 0;
				int varx = *(pDatax + pitchx * j + i * bitCountx);
				int vary = *(pDatay + pitchy * j + i * bitCounty);
				int varSum = *(pDataSum + pitchSum * j + i * bitCountSum);
				double degrees = atan2(vary, varx) / PI * 180;
				if (degrees < 0) degrees += 360;
				if ((degrees <= 22.5 && degrees >= 0) || (degrees >= 337.5)) {
					g1 = *(pDataSum + pitchSum * (j - 1) + i * bitCountSum);
					g2 = *(pDataSum + pitchSum * (j + 1) + i * bitCountSum);
				}
				else if ((degrees <= 67.5 && degrees > 22.5) || (degrees > 292.5 && degrees <= 337.5)) {
					g1 = *(pDataSum + pitchSum * (j + 1) + (i - 1) * bitCountSum);
					g2 = *(pDataSum + pitchSum * (j - 1) + (i + 1) * bitCountSum);
				}
				else if ((degrees <= 112.5 && degrees > 67.5) || (degrees > 247.5 && degrees <= 292.5)) {
					g1 = *(pDataSum + pitchSum * j + (i - 1) * bitCountSum);
					g2 = *(pDataSum + pitchSum * j + (i + 1) * bitCountSum);
				}
				else if ((degrees <= 157.5 && degrees > 112.5) || (degrees > 202.5 && degrees <= 247.5)) {
					g1 = *(pDataSum + pitchSum * (j - 1) + (i - 1) * bitCountSum);
					g2 = *(pDataSum + pitchSum * (j + 1) + (i + 1) * bitCountSum);
				}
				else {
					g1 = *(pDataSum + pitchSum * (j - 1) + i * bitCountSum);
					g2 = *(pDataSum + pitchSum * (j + 1) + i * bitCountSum);
				}
				if (varSum > g1 && varSum > g2) {
					*(pDataMove + pitchMove * j + i * bitCountMove) = varSum;
				}
				else {
					*(pDataMove + pitchMove * j + i * bitCountMove) = 0;
				}
			}
		}
	}

	if (!MyImage.IsNull()) MyImage.Destroy();
	MyImage.Create(width - 1, height - 1, 8, 0);
	MyImage.SetColorTable(0, 256, ColorTab);

	byte* pDataImage = (byte*)MyImage.GetBits();
	int pitchImage = MyImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	// 非极大值抑制
	double TL = dlg.Value1;
	double TH = dlg.Value2;
	// 对应的双阈值控制
	// 
	//for (int i = 1; i < width - 1; i++) {
	//	for (int j = 1; j < height - 1; j++) {
	//		int GradVal = *(pDataSum + pitchSum * j + i * bitCountSum);
	//		// 获得相应的梯度值
	//		int val = (UCHAR)(*(pDataMove + pitchMove * j + i * bitCountMove));

	//		if (val && (GradVal >= TH)) {
	//			*(pDataMove + pitchMove * j + i * bitCountMove) = 255;
	//			TraceEdge(i, j, TL);
	//		}
	//	}
	//}

	//for (int i = 1; i < width - 1; i++) {
	//	for (int j = 1; j < height - 1; j++) {
	//		if (((UCHAR)(*(pDataMove + pitchMove * j + i * bitCountMove))) != 255) {
	//			*(pDataImage + pitchImage * j + i * bitCountImage) = 0;
	//		}
	//		else {
	//			*(pDataImage + pitchImage * j + i * bitCountImage) = 255;
	//		}
	//	}
	//}
	for (int i = 1; i < width - 2; i++) {

		for (int j = 1; j < height - 2; j++) {

			int var = *(pDataMove + pitchMove * j + i * bitCountMove);

			if (var < TL) {
				*(pDataImage + pitchImage * j + i * bitCountImage) = 0;
			}

			else if (var > TH) {
				*(pDataImage + pitchImage * j + i * bitCountImage) = 255;
			}
			else {

				int value1 = *(pDataMove + pitchMove * j + (i - 1) * bitCountMove);
				int value2 = *(pDataMove + pitchMove * (j - 1) + (i - 1) * bitCountMove);
				int value3 = *(pDataMove + pitchMove * (j + 1) + (i - 1) * bitCountMove);
				int value4 = *(pDataMove + pitchMove * (j - 1) + i * bitCountMove);
				int value5 = *(pDataMove + pitchMove * (j + 1) + i * bitCountMove);
				int value6 = *(pDataMove + pitchMove * j + (i + 1) * bitCountMove);
				int value7 = *(pDataMove + pitchMove * (j - 1) + (i + 1) * bitCountMove);
				int value8 = *(pDataMove + pitchMove * (j + 1) + (i + 1) * bitCountMove);
				if (value1 > TH || value2 > TH || value3 > TH || value4 > TH || value5 > TH || value6 > TH || value7 > TH || value8 > TH) {
					*(pDataImage + pitchImage * j + i * bitCountImage) = 255;
				}
			}
		}
	}
	Invalidate();
}

// 大津法
void CMFCView::OnOtsu()
{
	int width = MyImage.GetWidth();
	int height = MyImage.GetHeight();
	byte* pDataImage = (byte*)MyImage.GetBits();
	int pitchImage = MyImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;

	double GraySum[256];
	double Gray_prob[256];
	double m[256];
	int GrayNum[256];
	memset(GrayNum, 0, sizeof(GrayNum));

	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			int var = *(pDataImage + pitchImage * j + i * bitCountImage);
			GrayNum[var]++;
		}
	}
	// 相应的归一化结果
	for (int i = 0; i < 256; i++)
		Gray_prob[i] =1.0* GrayNum[i] / (width * height);
	GraySum[0] = Gray_prob[0];
	m[0] = 0;
	for (int i = 1; i < 256; i++) { 
		GraySum[i] = Gray_prob[i] + GraySum[i - 1];
		m[i] = m[i - 1] + i * Gray_prob[i];
	}

	double mG = m[255];
	int k = 0;
	double  MAX = 0;
	for (int i = 0; i < 256; i++) {
		double ans = (mG * GraySum[i] - m[i]) * (mG * GraySum[i] - m[i]) / (GraySum[i] * (1 - GraySum[i]) + 1e-10);
		if (MAX < ans) {
			MAX = ans;
			k = i;
		}
	}

	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			int var= *(pDataImage + pitchImage * j + i * bitCountImage);
			if (var <= k) {
				*(pDataImage + pitchImage * j + i * bitCountImage) = 0;
			}
			else {
				*(pDataImage + pitchImage * j + i * bitCountImage) = 255;
			}
		}
	}
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}



void CMFCView::OnFvalue()
{
	FFT2(0, 1);
	Invalidate();
	// TODO: 在此添加命令处理程序代码
}


// 对于相应的值进行求解
void CMFCView::TraceEdge(int w, int h, int nThrLow) {
	int xNum[8] = { 1,1,0,-1,-1,-1,0,1 };
	int yNum[8] = { 0,1,1,1,0,-1,-1,-1 };
	bool change = true;
	int xx = 0, yy = 0;
	// 获得相应的颜色信息
	// 相应的值
	byte* pDataImage = (byte*)MyImage.GetBits();
	int pitchImage = MyImage.GetPitch();
	int bitCountImage = MyImage.GetBPP() / 8;
	byte* pDataSum = (byte*)SobelSum.GetBits();
	int bitCountSum = SobelSum.GetBPP() / 8;
	int pitchSum = SobelSum.GetPitch();
	byte* pDataGray = (byte*)GrayImage.GetBits();
	int bitCountGray = GrayImage.GetBPP() / 8;
	int pitchGray = GrayImage.GetPitch();
	byte* pDataMove = (byte*)MoveImage.GetBits();
	int pitchMove = MoveImage.GetPitch();
	int bitCountMove = MoveImage.GetBPP() / 8;

	while (change) {
		change = false;
		for (int k = 0; k < 8; k++) {
			xx = w + xNum[k];
			yy = h + yNum[k];
			if (xx < GrayImage.GetWidth() && yy < GrayImage.GetHeight()) {
				int val = (UCHAR)(*(pDataMove + pitchMove * yy + xx * bitCountMove));
				int gradVal = (UCHAR)(*(pDataSum + pitchSum * yy + xx * bitCountSum));
				if (val == 200 && gradVal > nThrLow) {
					change = true;
					*(pDataMove + pitchMove * yy + xx * bitCountMove) = 255;
					h = yy;
					w = xx;
					break;
				}
			}
		}
	}
}