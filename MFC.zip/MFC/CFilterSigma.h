﻿#pragma once


// CFilterSigma 对话框

class CFilterSigma : public CDialogEx
{
	DECLARE_DYNAMIC(CFilterSigma)

public:
	CFilterSigma(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CFilterSigma();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG6 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	CString CValueSigma;
	float ValueSigma;
	afx_msg void OnBnClickedOk();
};
