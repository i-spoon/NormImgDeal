﻿// CCannyEdge.cpp: 实现文件
//

#include "pch.h"
#include "MFC.h"
#include "CCannyEdge.h"
#include "afxdialogex.h"


// CCannyEdge 对话框

IMPLEMENT_DYNAMIC(CCannyEdge, CDialogEx)

CCannyEdge::CCannyEdge(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG7, pParent)
	, CValue1(_T(""))
	, CValue2(_T(""))
{

}

CCannyEdge::~CCannyEdge()
{
}

void CCannyEdge::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, CValue1);
	DDX_Text(pDX, IDC_EDIT2, CValue2);
}


BEGIN_MESSAGE_MAP(CCannyEdge, CDialogEx)
	ON_BN_CLICKED(IDOK, &CCannyEdge::OnBnClickedOk)
END_MESSAGE_MAP()


// CCannyEdge 消息处理程序


void CCannyEdge::OnBnClickedOk()
{
	GetDlgItem(IDC_EDIT1)->GetWindowText(CValue1);
	GetDlgItem(IDC_EDIT2)->GetWindowText(CValue2);
	Value1 = _ttof(CValue1);
	Value2 = _ttof(CValue2);
	// TODO: 在此添加控件通知处理程序代码
	CDialogEx::OnOK();
}
