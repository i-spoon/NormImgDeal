#include "pch.h"
#include "CMatrix.h"

// ��Ӧ�˲����Ĺ��캯��

AreaFilter::AreaFilter() {
	if (Filter != nullptr) delete[]Filter;
	Filter = new double* [1000];
	// ��Ӧ�Ľ��
	for (int i = 0; i < 1000; i++) {
		Filter[i] = new double[1000];
	}
	// ������Ӧ��Ч��
	memset(Filter, 0, sizeof(Filter));
}

// ����һ����Ӧ��С�ĸ�˹�˲���
void AreaFilter::BuildGauss(int n,double Sigma) {
	// ������Ӧ��С�ĵ�ͨ��˹�˲���
	FilterSum = 0;
	width = n * 2 + 1;
	height = n * 2 + 1;
	int MIDX = n;
	int MIDY = n;
	for (int i = MIDX+1; i <= width; i++) {
		for (int j = MIDY+1; j <= height; j++) {
			Filter[i][j] = Filter[i][height - j + 1] = Filter[width - i + 1][j] = Filter[width - i + 1][height - j + 1] = exp(-((i-1 - MIDX) * (i-1 - MIDX) + (j -1- MIDY) * (j -1- MIDY)) / (2.0*Sigma*Sigma));
			// ����������Ϊ��˹�˲��ǶԳƵ�
		}
	}
	for (int i = 1; i <= width; i++)
		for (int j = 1; j <= height; j++)
			FilterSum += Filter[i][j];
}


void AreaFilter::BuildLog(int n, double Sigma) {
	FilterSum = 0;
	width = n * 2 + 1;
	height = n * 2 + 1;
	int MIDX = n;
	int MIDY = n;
	// ����һ����Ӧ���˲�����
	for (int i = MIDX + 1; i <= width; i++) {
		for (int j = MIDY + 1; j <= height; j++) {
			Filter[i][j] = Filter[i][height - j + 1] = Filter[width - i + 1][j] = Filter[width - i + 1][height - j + 1] = -( ( (i - 1 - MIDX) * (i - 1 - MIDX) + (j - 1 - MIDY) * (j - 1 - MIDY) - 2*Sigma*Sigma ) / pow(Sigma,4))*exp(-((i - 1 - MIDX) * (i - 1 - MIDX) + (j - 1 - MIDY) * (j - 1 - MIDY)) / (2.0 * Sigma * Sigma));
			// ����������Ϊ��˹�˲��ǶԳƵ�
		}
	}
	for (int i = 1; i <= width; i++)
		for (int j = 1; j <= height; j++)
			FilterSum += Filter[i][j];
}
// ������Ӧ�ĺ����˲��� �����Ϻ���Ӧ�����ӹ�����һ����
void AreaFilter::BuildSqure(int n) {
	FilterSum = 0;
	height = n * 2 + 1;
	width = n * 2 + 1;
	int MIDX = n;
	int MIDY = n;
	int cntx = MIDX;
	int cnty = MIDY;
	// ��ι���һ����ʽ�˲���
	for (int i = MIDX+1; i <= width; i++) {
		for (int j = MIDY+1; j <= height; j++) {
			Filter[i][j] = Filter[i][height - j + 1] = Filter[width - i + 1][j] = Filter[width - i + 1][height - j + 1] = sqrt((i-1 - MIDX) * (i-1 - MIDX) + (j-1 - MIDY) * (j-1 - MIDY));
		}
	}

	for (int i = 1; i <= width; i++)
		for (int j = 1; j <= height; j++)
			FilterSum += Filter[i][j];
}

// ����ƽ�����˲���
void AreaFilter::BuildEqual(int n) {
	width = height = n*2+1;
	for (int i = 1; i <= n*2+1; i++) {
		for (int j = 1; j <= n*2+1; j++) {
			Filter[i][j] = 1;
		}
	}
	FilterSum = width * height;
	// �õ���Ӧ���˲��ܺ�
}

void AreaFilter::BuildLaplace(int n) {
	// ���ֳ������˲���
	FilterSum = 0;
	height = width = 3;
	switch(n) {
		case 1:
			Filter[1][2] = Filter[2][1] = Filter[2][3] = Filter[3][2] = 1;
			Filter[1][1] = Filter[1][3] = Filter[3][1] = Filter[3][3] = 0;
			Filter[2][2] = -4;
			break;
		case 2:
			for (int i = 1; i <= 3; i++)
				for (int j = 1; j <= 3; j++)
					Filter[i][j] = 1;
			Filter[2][2] = -8;
			break;
		case 3:
			Filter[1][2] = Filter[2][1] = Filter[2][3] = Filter[3][2] = -1;
			Filter[1][1] = Filter[1][3] = Filter[3][1] = Filter[3][3] = 0;
			Filter[2][2] = 4;
			break;
		case 4:
			for (int i = 1; i <= 3; i++)
				for (int j = 1; j <= 3; j++)
					Filter[i][j] = -1;
			Filter[2][2] = 8;
			break;
	}
}

void CMatrix::Mulitpty(AreaFilter a) {
	// ������Ӧ���˲���
	for (int i = 1; i <=a.getWidth(); i++) {
		for (int j = 1; j <=a.getHeight(); j++) {
			output[i][j] = input[i][j] * a.getNum(i, j);
			// ȥ������Ӧ�Ľ��
		}
	}
}

// ��������ĸ���Ҷ�˲���
CMatrix::CMatrix() {
	if (input != nullptr) delete[]input;
	if (output != nullptr) delete[]output;
	input = new double* [1000];
	output = new double* [1000];
	for (int i = 0; i < 1000; i++) {
		input[i] = new double[1000];
		output[i] = new double[1000];
	}
}

// ��Ӧ�Ĺ��캯��
CMatrix::CMatrix(CMyImage file, int n) {

	width = file.GetWidth();
	height = file.GetHeight();
	// ��̬������Ӧ������
	if (input != nullptr) delete[]input;
	if (output != nullptr) delete[]output;
	input = new double* [1000];
	output = new double* [1000];
	for (int i = 0; i < 1000; i++) {
		input[i] = new double[1000];
		output[i] = new double[1000];
	}

	FilterWidth = n;// ������Ӧ�ĸ�ֵ����
	FilterHeight = n;
	byte* pDataImage = (byte*)file.GetBits();
	int pitchImage = file.GetPitch();
	int bitCountImage = file.GetBPP() / 8;
	memset(input, 0, sizeof(input));
	memset(output, 0, sizeof(output));
	for (int i = 1; i < width + 2 * n + 2; i++) {
		for (int j = 1; j < height + 2 * n + 2; j++)
			input[i][j] = 0;
	}
	// ���õ���0����ķ�ʽ
	// ������Ӧ�ĸ��Ʋ���
	for (int i = n + 1; i < width + n + 1; i++) {
		for (int j = n + 1; j < height + n + 1; j++)
			input[i][j] = *(pDataImage + pitchImage * (j - n - 1) + (i - n - 1) * bitCountImage);
	}

}

// ������Ӧ�ľ�������
void CMatrix::operator*(AreaFilter a) {

	FilterHeight = a.getHeight()/2;
	FilterWidth = a.getWidth()/2;
	for (int i = FilterWidth + 1; i < FilterWidth + width + 1; i++) {
		for (int j = FilterHeight + 1; j < FilterHeight + height + 1; j++) {
			float sum = 0;
			for (int k = -FilterWidth; k <= FilterWidth; k++) {
				for (int h = -FilterHeight; h <= FilterHeight; h++) {
					if (a.getSum()) {
						double value = 1.0 / a.getSum() * a.getNum(k + FilterWidth + 1, h + FilterHeight + 1);
						sum += value*input[i + k][j + h];
					}
					else {
						sum+= input[i + k][j + h] * a.getNum(k + FilterWidth + 1, h + FilterHeight + 1);
					}
				}
			}
			output[i - FilterWidth][j - FilterHeight] = min(sum,255);
		}
	}
}

// д����Ӧ���ļ�
void CMatrix::WriteFile(CMyImage& file) {
	byte* pDataImage = (byte*)file.GetBits();
	int pitchImage = file.GetPitch();
	int bitCountImage = file.GetBPP() / 8;
	// ���õ���0����ķ�ʽ
	// ������Ӧ�ĸ��Ʋ���
	height = file.GetHeight();
	width = file.GetWidth();
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++)
			*(pDataImage + pitchImage * j + i * bitCountImage) = UCHAR(max(min(255, output[i+1][j+1]+0.5),0));
	}
}

// ������Ӧ�ĸ�ֵ����
CMatrix::CMatrix(CMyImage file) {
	width = file.GetWidth();
	height = file.GetHeight();
	// ��̬������Ӧ������
	if (input != nullptr) delete[]input;
	if (output != nullptr) delete[]output;
	input = new double* [1000];
	output = new double* [1000];
	for (int i = 0; i < 1000; i++) {
		input[i] = new double[1000];
		output[i] = new double[1000];
	}

	byte* pDataImage = (byte*)file.GetBits();
	int pitchImage = file.GetPitch();
	int bitCountImage = file.GetBPP() / 8;
	memset(input, 0, sizeof(input));
	memset(output, 0, sizeof(output));
	for (int i = 1; i < width + 1; i++) {
		for (int j = 1; j < height+1; j++)
			input[i][j] = *(pDataImage + pitchImage * (j - 1) + (i - 1) * bitCountImage);
	}
	// ����Ӧ��ֵ��ֵ��output
}

void CMatrix::setMatrix(CMyImage file) {
	width = file.GetWidth();
	height = file.GetHeight();
	byte* pDataImage = (byte*)file.GetBits();
	int pitchImage = file.GetPitch();
	int bitCountImage = file.GetBPP() / 8;
	memset(input, 0, sizeof(input));
	memset(output, 0, sizeof(output));
	for (int i = 1; i < width + 1; i++) {
		for (int j = 1; j < height + 1; j++)
			input[i][j] = *(pDataImage + pitchImage * (j - 1) + (i - 1) * bitCountImage);
	}
}

// ��������Ӧ��
void AreaFilter::BuildFx() {
	memset(Filter, 0, sizeof(Filter));
	Filter[1][1] = -1;
	Filter[2][1] = 1;
}

void AreaFilter::BuildFy() {
	memset(Filter, 0, sizeof(Filter));
	Filter[1][1] = -1;
	Filter[1][2] = 1;
}

void CMatrix::gradFx(CMyImage file) {
	int width = file.GetWidth();
	int height = file.GetHeight();

	byte* pDataImage = (byte*)file.GetBits();
	int pitchImage = file.GetPitch();
	int bitCountImage = file.GetBPP() / 8;

	// ��ȡ��Ӧ��ͼ�ε�λ��
	// Ϊ�˷������ ����Ӧ��input���õ���Ӧ��λ��
	
	for (int i = 3; i < width+1; i++) {
		for (int j = 3; j < height+1; j++) 
			output[i-2][j-2] = abs(input[i][j] - input[i][j - 1]);
	}
}

void CMatrix::gradFy(CMyImage file) {

	int width = file.GetWidth();
	int height = file.GetHeight();

	byte* pDataImage = (byte*)file.GetBits();
	int pitchImage = file.GetPitch();
	int bitCountImage = file.GetBPP() / 8;

	// ��ȡ��Ӧ��ͼ�ε�λ��
	// Ϊ�˷������ ����Ӧ��input���õ���Ӧ��λ��
	for (int i = 3; i < width + 1; i++) {
		for (int j = 3; j < height + 1; j++)
			output[i-2][j-2] = abs(input[i][j] - input[i - 1][j]);
	}
}

void CMatrix::gradSum(CMyImage file) {
	int width = file.GetWidth();
	int height = file.GetHeight();

	byte* pDataImage = (byte*)file.GetBits();
	int pitchImage = file.GetPitch();
	int bitCountImage = file.GetBPP() / 8;

	// ��ȡ��Ӧ��ͼ�ε�λ��
	// Ϊ�˷������ ����Ӧ��input���õ���Ӧ��λ��
	for (int i = 3; i < width + 1; i++) {
		for (int j = 3; j < height + 1; j++)
			output[i - 2][j - 2] = abs(input[i][j] - input[i - 1][j]) + abs(input[i][j] - input[i][j - 1]);
	}
}

void AreaFilter::BuildSobelx() {
	width = height = 3;
	Filter[1][1] = -1;
	Filter[1][2] = Filter[2][2] = Filter[3][2] = 0;
	Filter[1][3] = 1;
	Filter[2][1] = -2;
	Filter[2][3] = 2;
	Filter[3][1] = -1;
	Filter[3][3] = 1;
}

void AreaFilter::BuildSobely() {
	width = height = 3;
	Filter[1][1] = 1;
	Filter[1][2] = 2;
	Filter[1][3] = 1;
	Filter[3][1] = -1;
	Filter[3][2] = -2;
	Filter[3][3] = -1;
	Filter[2][1] = Filter[2][2] = Filter[2][3] = 0;
}

// ������Ӧ����ֵ ������Ӧ��ֵ�洢��output��
void CMatrix::SobelSum(CMyImage Sobelx, CMyImage Sobely) {
	height = Sobelx.GetHeight();
	width = Sobelx.GetWidth();

	byte* pDatax = (byte*)Sobelx.GetBits();
	int pitchx = Sobelx.GetPitch();
	int bitCountx = Sobelx.GetBPP() / 8;


	byte* pDatay = (byte*)Sobely.GetBits();
	int pitchy = Sobely.GetPitch();
	int bitCounty = Sobely.GetBPP() / 8;


	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			int varx = *(pDatax + pitchx * j + i * bitCountx);	
			int vary = *(pDatax + pitchx * j + i * bitCountx);
			output[i + 1][j + 1] = sqrt(1.0*varx * varx + 1.0*vary * vary);
		}
	}
}

void CMatrix::SobelSum(CMyImage file) {
	int width = file.GetWidth();
	int height = file.GetHeight();

	byte* pDataImage = (byte*)file.GetBits();
	int pitchImage = file.GetPitch();
	int bitCountImage = file.GetBPP() / 8;
	int k = 0;
	for (int i = 2; i < width; i++) {
		for (int j = 2; j < height; j++) {
			double varx= abs(input[i - 1][j - 1] + 2 * input[i][j - 1] + input[i + 1][j - 1] - input[i - 1][j + 1] - 2 * input[i][j+1] - input[i + 1][j + 1]);
			double  vary = abs(input[i - 1][j - 1] + 2 * input[i - 1][j] + input[i - 1][j + 1] - input[i + 1][j - 1] - 2 * input[i + 1][j] - input[i + 1][j + 1]);
			output[i-1][j-1] = varx + vary;
		}
	}
}

void CMatrix::SobelX(CMyImage file) {
	int width = file.GetWidth();
	int height = file.GetHeight();
	byte* pDataImage = (byte*)file.GetBits();
	int pitchImage = file.GetPitch();
	int bitCountImage = file.GetBPP() / 8;
	for (int i = 2; i < width; i++) {
		for (int j = 2; j < height; j++)
			output[i - 1][j - 1] = abs(input[i - 1][j - 1] + 2 * input[i][j - 1] + input[i + 1][j - 1] - input[i - 1][j + 1] - 2 * input[i][j + 1] - input[i + 1][j + 1]);
	}

}


void CMatrix::SobelY(CMyImage file) {
	int width = file.GetWidth();
	int height = file.GetHeight();
	byte* pDataImage = (byte*)file.GetBits();
	int pitchImage = file.GetPitch();
	int bitCountImage = file.GetBPP() / 8;
	for (int i = 2; i < width; i++) {
		for (int j = 2; j < height; j++)
			output[i - 1][j - 1] = abs(input[i - 1][j - 1] + 2 * input[i - 1][j] + input[i - 1][j + 1] - input[i + 1][j - 1] - 2 * input[i + 1][j] - input[i + 1][j + 1]);
	}
}

void CMatrix::zerosJudge() {

	double** tmpDate = new double* [1000];

	for (int i = 0; i < 1000; i++)
		tmpDate[i] = new double[1000];
	// �ж���Ӧ�����
	for (int i = 1; i <= width; i++) {
		for (int j = 1; j < height; j++) {
			// �ж���Ӧ��ֵ
			if (output[i][j] * output[i][j + 1] < 0 && abs(output[i][j] - output[i][j + 1]) >= 10) {
				tmpDate[i][j] = 255;
			}
			else {
				tmpDate[i][j] = 0;
			}
		}
	}
	for (int i = 1; i <= width; i++) {
		for (int j = 1; j <= height; j++) {
			output[i][j] = tmpDate[i][j];
		}
	}
	for (int i = 1; i < 1000; i++)
		delete tmpDate[i];
}