﻿// CDialogMove.cpp: 实现文件
//

#include "pch.h"
#include "MFC.h"
#include "CDialogMove.h"
#include "afxdialogex.h"


// CDialogMove 对话框

IMPLEMENT_DYNAMIC(CDialogMove, CDialogEx)

CDialogMove::CDialogMove(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, mValueX(_T("-100"))
	, mValueY(_T("-100"))
{

}

CDialogMove::~CDialogMove()
{
}

void CDialogMove::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, mValueX);
	DDX_Text(pDX, IDC_EDIT2, mValueY);
}


BEGIN_MESSAGE_MAP(CDialogMove, CDialogEx)
	ON_BN_CLICKED(IDOK, &CDialogMove::OnBnClickedOk)
END_MESSAGE_MAP()


// CDialogMove 消息处理程序


void CDialogMove::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码
	// 获取相应的空间内容
	// 把相应的传递过来
	GetDlgItem(IDC_EDIT1)->GetWindowText(mValueX);
	GetDlgItem(IDC_EDIT2)->GetWindowText(mValueY);
	std::string strX, strY;
	ValueX = _ttoi(mValueX);
	ValueY = _ttoi(mValueY);
	CDialogEx::OnOK();
}
