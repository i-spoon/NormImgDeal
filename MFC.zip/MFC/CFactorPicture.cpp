﻿// CFactorPicture.cpp: 实现文件
//

#include "pch.h"
#include "MFC.h"
#include "CFactorPicture.h"
#include "afxdialogex.h"


// CFactorPicture 对话框

IMPLEMENT_DYNAMIC(CFactorPicture, CDialogEx)

CFactorPicture::CFactorPicture(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG4, pParent)
	, mValueC(_T("1"))
	, mValueR(_T("0.8"))
{

}

CFactorPicture::~CFactorPicture()
{
}

void CFactorPicture::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, mValueC);
	DDX_Text(pDX, IDC_EDIT2, mValueR);
}


BEGIN_MESSAGE_MAP(CFactorPicture, CDialogEx)
	ON_BN_CLICKED(IDOK, &CFactorPicture::OnBnClickedOk)
END_MESSAGE_MAP()


// CFactorPicture 消息处理程序


void CFactorPicture::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码
	GetDlgItem(IDC_EDIT1)->GetWindowText(mValueC);
	ValueC = _ttof(mValueC);
	GetDlgItem(IDC_EDIT2)->GetWindowText(mValueR);
	ValueR = _ttof(mValueR);
	CDialogEx::OnOK();
}
