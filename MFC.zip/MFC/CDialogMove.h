﻿#pragma once


// CDialogMove 对话框
#include<string>
class CDialogMove : public CDialogEx
{
	DECLARE_DYNAMIC(CDialogMove)

public:
	CDialogMove(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CDialogMove();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	CString mValueX=_T("100");
	CString mValueY=_T("100");
	int ValueX;
	int ValueY;
	afx_msg void OnBnClickedOk();
};
