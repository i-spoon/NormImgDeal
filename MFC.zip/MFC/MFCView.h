﻿
// MFCView.h: CMFCView 类的接口
//

#pragma once
#include"CMyImage.h"
#include "CLogPicture.h"
#include"CTranA.h"
#include"CFactorPicture.h"
#include"CMatrix.h"
#include"CFilterSize.h"
#include"CFilterSigma.h"
#include"CCannyEdge.h"
#include<complex>
#include<vector>
#include<cmath>
class CMFCView : public CView
{
protected: // 仅从序列化创建
	CMFCView() noexcept;
	DECLARE_DYNCREATE(CMFCView)

// 特性
public:
	CMFCDoc* GetDocument() const;

// 操作
public:

// 重写
public:
	virtual void OnDraw(CDC* pDC);  // 重写以绘制该视图
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// 实现
public:
	virtual ~CMFCView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 生成的消息映射函数
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
	void MatrixMulitpy();
	int Gray[256] = { 0 };// 记录相应像素的颜色个数
	double GrayProb[256] = { 0 };// 相应的分布函数
	double GrayDistribution[256] = { 0 };// 累计密度
	int GrayEqual[256] = { 0 };// 建立相应的映射关系

public:
	std::vector<double>Angle;
	AreaFilter filter;
	double A[3][3];// 相应的转换矩阵
	double B[3][3];// 创建相应的矩阵，最终的结果是在相应的A中的
	CString strPicPath;
	CString extname;
	CBitmap mBitMap;
	CMyImage MyImage;
	CMyImage GrayImage;
	CMyImage MoveImage;
	CFile FileName;
	CMyImage Sobelx;
	CMyImage Sobely;
	CMyImage SobelSum;
	LPBYTE* mLpData=nullptr;
	BITMAPINFOHEADER* mPBMIH=nullptr;
	LPVOID mLpvColorTable;
	int mNColorTableEntries;
	float mFMultiple;// 放大的倍数
	CPoint mOriginSrcPoint=(0,0);// 原图的坐标原点
	int mWidthSrc;// 原图的宽度
	int mHeightSrc;// 原图的高度
	CPoint mPtRollPointClient=(0,0);// 滚轮滚动时工作区的坐标点
	CPoint mPtRollPointScreen=(0,0);// 滚轮滚动时屏幕坐标点
	CRect mRectDraw;// 绘图区的矩形区域
	void CleanUp();// 清楚相应的内容
	double getAngle(int i, int j);

	afx_msg void OnFileOpen();
	std::complex<double>* CInput=nullptr;
	std::complex<double>* CFilter = nullptr;
	void BuildIdea(int height,int width,int nFreq);
	void BuildGauss(int height, int width, double dSigma);
	void BuildHGauss(int height, int width, double dSigma);
	void BuildHIdea(int height, int width, int nFreq);
	void BuildBt(int hegiht, int width, double dSigma,int n);
	void BuildHBt(int height, int width, double dSigma,int n);
	void FFT1(std::complex<double>* TD, std::complex<double>* FD, int r);
	// 其中TD表示的是指向时域的指针
	// FD表示的是指向频域的指针
	
	void FFT2(bool expand, BYTE color);
	// 当expand为0的时候，表示的是缩减操作
	// 当expand为1的时候，表示的是填充操作，其中填充字符使用的是color作为填充
	void IFFT1(std::complex<double>* FD, std::complex<double>* TD, int r);
	void IFFT2(int lWidth, int lHeight);
	// 输入图像的大小
	bool AttachFromFile(CFile& file);
	bool MoveTranForm(int x, int y);
	bool TranA(float a);
	bool LogPicture(float c);
	bool FactorPicture(float c, float r);
	void TraceEdge(int w, int h, int TL);
	afx_msg void OnGray();
	afx_msg void OnMove();
	afx_msg void OnMirrorsHeight();
	afx_msg void OnMirrorsWidth();
	afx_msg void OnImageT();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnTrana();
	afx_msg void OnFileSave();
	afx_msg void OnColorBack();
	afx_msg void OnHistogram();
	afx_msg void OnLogTran();
	afx_msg void OnFactor();
	afx_msg void OnEqual();
	afx_msg void OnBox();
	afx_msg void OnGauss();
	afx_msg void OnLaplace();
	afx_msg void OnHighFilter();
	afx_msg void OnIdeaLower();
	afx_msg void OnGaussLower();
	afx_msg void OnIdeaHigher();
	afx_msg void OnGaussHigher();
	afx_msg void OnBlower();
	afx_msg void OnBhigher();
	afx_msg void OnGradx();
	afx_msg void OnGrady();
	afx_msg void OnGradsum();
	afx_msg void OnLogEdge();
	afx_msg void OnCannyEdge();
	afx_msg void OnOtsu();
	afx_msg void OnFvalue();
};

#ifndef _DEBUG  // MFCView.cpp 中的调试版本
inline CMFCDoc* CMFCView::GetDocument() const
   { return reinterpret_cast<CMFCDoc*>(m_pDocument); }
#endif

