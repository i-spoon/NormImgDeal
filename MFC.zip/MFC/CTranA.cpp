﻿// CTranA.cpp: 实现文件
//

#include "pch.h"
#include "MFC.h"
#include "CTranA.h"
#include "afxdialogex.h"


// CTranA 对话框

IMPLEMENT_DYNAMIC(CTranA, CDialogEx)

CTranA::CTranA(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG2, pParent)
	, mTranA(_T("45"))
{

}

CTranA::~CTranA()
{
}

void CTranA::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, mTranA);
}


BEGIN_MESSAGE_MAP(CTranA, CDialogEx)
	ON_BN_CLICKED(IDOK, &CTranA::OnBnClickedOk)
END_MESSAGE_MAP()


// CTranA 消息处理程序


void CTranA::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码
	GetDlgItem(IDC_EDIT1)->GetWindowText(mTranA);
	mValueA = _ttof(mTranA);
	CDialogEx::OnOK();
}
