﻿#pragma once


// CLogPicture 对话框

class CLogPicture : public CDialogEx
{
	DECLARE_DYNAMIC(CLogPicture)

public:
	CLogPicture(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CLogPicture();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG3 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	CString mValueC;
	CString mValueR;
	float ValueC;
	afx_msg void OnBnClickedOk();
};
