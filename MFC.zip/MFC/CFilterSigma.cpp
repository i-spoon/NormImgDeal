﻿// CFilterSigma.cpp: 实现文件
//

#include "pch.h"
#include "MFC.h"
#include "CFilterSigma.h"
#include "afxdialogex.h"


// CFilterSigma 对话框

IMPLEMENT_DYNAMIC(CFilterSigma, CDialogEx)

CFilterSigma::CFilterSigma(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG6, pParent)
	, CValueSigma(_T(""))
{

}

CFilterSigma::~CFilterSigma()
{
}

void CFilterSigma::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, CValueSigma);
}


BEGIN_MESSAGE_MAP(CFilterSigma, CDialogEx)
	ON_BN_CLICKED(IDOK, &CFilterSigma::OnBnClickedOk)
END_MESSAGE_MAP()


// CFilterSigma 消息处理程序


void CFilterSigma::OnBnClickedOk()
{
	GetDlgItem(IDC_EDIT1)->GetWindowText(CValueSigma);
	ValueSigma = _ttof(CValueSigma);
	// TODO: 在此添加控件通知处理程序代码
	CDialogEx::OnOK();
}
