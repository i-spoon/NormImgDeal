﻿#pragma once


// CFactorPicture 对话框

class CFactorPicture : public CDialogEx
{
	DECLARE_DYNAMIC(CFactorPicture)

public:
	CFactorPicture(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CFactorPicture();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG4 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	CString mValueC;
	CString mValueR;
	float ValueC;
	float ValueR;// 进行相应的统计操作
	afx_msg void OnBnClickedOk();
};
