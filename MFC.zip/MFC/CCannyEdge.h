﻿#pragma once


// CCannyEdge 对话框

class CCannyEdge : public CDialogEx
{
	DECLARE_DYNAMIC(CCannyEdge)

public:
	CCannyEdge(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CCannyEdge();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG7 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	double Value1;
	double Value2;
	CString CValue1;
	CString CValue2;
	afx_msg void OnBnClickedOk();
};
