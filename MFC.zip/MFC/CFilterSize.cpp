﻿// CFilterSize.cpp: 实现文件
//

#include "pch.h"
#include "MFC.h"
#include "CFilterSize.h"
#include "afxdialogex.h"


// CFilterSize 对话框

IMPLEMENT_DYNAMIC(CFilterSize, CDialogEx)

CFilterSize::CFilterSize(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG5, pParent)
	, mValueSize(_T(""))
	, mValueSigma(_T("7"))
{

}

CFilterSize::~CFilterSize()
{
}

void CFilterSize::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, mValueSize);
	DDX_Text(pDX, IDC_EDIT2, mValueSigma);
}


BEGIN_MESSAGE_MAP(CFilterSize, CDialogEx)
	ON_BN_CLICKED(IDOK, &CFilterSize::OnBnClickedOk)
END_MESSAGE_MAP()


// CFilterSize 消息处理程序


void CFilterSize::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码]
	GetDlgItem(IDC_EDIT1)->GetWindowText(mValueSize);
	GetDlgItem(IDC_EDIT2)->GetWindowText(mValueSigma);
	ValueSize = _ttoi(mValueSize)/2;
	ValueSigma = _ttoi(mValueSigma);
	CDialogEx::OnOK();
}
